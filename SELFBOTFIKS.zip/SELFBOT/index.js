//BASE BY MHANKBARBAR
//RECODE BY ITSME ABDILLAH
//RECODE DOANG BANG, JAN DIBULLY
//GA HAPUS TQTQ ANAK HALAL
//GA SEMUA CASE BUATAN GW, ADA YG NYOLONG
//-
//PACKAGE NPM
const qrcode = require("qrcode-terminal") 
const moment = require("moment-timezone") 
const fs = require("fs")
const got = require("got");
const axios = require('axios')
const crypto = require('crypto')
const delay = require('delay')
const brainly = require('brainly-scraper')
const ffmpeg = require('fluent-ffmpeg')
const FormData = require('form-data')
const imgbb = require('imgbb-uploader')
const gis = require('g-i-s');
const request = require('request')
const fetch = require('node-fetch')
const imageToBase64 = require('image-to-base64')
const path = require('path')
const cd = 4.32e+7
const { exec } = require("child_process")
const { removeBackgroundFromImageFile } = require('remove.bg')
//-
//DATA LIB
const { color, bgcolor } = require('./lib/color')
const { bahasa } = require('./lib/bahasa')
const { negara } = require('./lib/kodenegara')
const { cheat } = require('./lib/cheat')
const { animesaran } = require('./lib/animesaran')
const { animesaran2 } = require('./lib/animesaran2')
const { donasi } = require('./lib/donasi')
const { infown } = require('./lib/infown')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const { snk } = require('./lib/snk')
const fontPath = ('./lib/Zahraaa.ttf')
const { wait, simih, h2k, generateMessageID, getRandom, getBuffer, banner, start, info, success, close } = require('./lib/functions')
const Exif = require('./lib/exif');
const exif = new Exif();
//-
//PLUGINS
const { convertSticker } = require("./plugins/swm.js")
//-
//DPUHY
const { dpuhy } = require('./asu')
//-
//FILE JSON
const { LeysApi, LolHuman, DapApi } = JSON.parse(fs.readFileSync('./src/apikey.json'))
const dapyog = JSON.parse(fs.readFileSync('./src/settings.json'))
const _leveling = JSON.parse(fs.readFileSync('./database/leveling.json'))
const _level = JSON.parse(fs.readFileSync('./database/level.json'))
const welkom = JSON.parse(fs.readFileSync('./database/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./database/nsfw.json'))
const ban = JSON.parse(fs.readFileSync('./database/banned.json'))
const user = JSON.parse(fs.readFileSync('./database/user.json'))
const audionye = JSON.parse(fs.readFileSync('./database/audio.json'))
const samih = JSON.parse(fs.readFileSync('./database/simi.json'))
const event = JSON.parse(fs.readFileSync('./database/event.json'))
const _limit = JSON.parse(fs.readFileSync('./database/limit.json'))
const uang = JSON.parse(fs.readFileSync('./database/uang.json'))
const antilink = JSON.parse(fs.readFileSync('./database/antilink.json'))
const antivirtex = JSON.parse(fs.readFileSync('./database/antivirtex.json'))
const bad = JSON.parse(fs.readFileSync('./database/bad.json'))
const badword = JSON.parse(fs.readFileSync('./database/badword.json'))
//-
//SETTING (atur di src/settings.json)
namabot = dapyog.namabot
namaowner = dapyog.namaowner
nomerlu = dapyog.nomerlu
limitawal = dapyog.limitawal
memberlimit = dapyog.memberlimit
igstah = dapyog.instagramlu
//-
//WA CONNECTION
const {
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   GroupSettingChange,
   waChatKey,
   mentionedJid,
   processTime,
   processTicksAndRejections,
   ECONNABORTED,
   apikey,
   WA_DEAFULT_EPHEMERAL,
   DataView,
   TypedArray,
} = require("@adiwajshing/baileys")
//-
//JANGAN DIAPA APAIN ENTAR EROR
prefix = ''
blocked = []
a = '\`\`\`'
banChats = true
publik = false
setgrup = '39347060205 4-1351628616@g.us'
fake = `${namabot} ANTIDELETE`
numbernye = '0'
//-
//VCARD
const vcard1 = 'BEGIN:VCARD\n' 
              + 'VERSION:3.0\n' 
              + `FN:${namaowner}ツ\n`
              + `ORG: Owner ${namabot};\n`
              + `TEL;type=CELL;type=VOICE;waid=${nomerlu}:+${nomerlu}\n`
              + 'END:VCARD'
//-
//XP
const getLevelingXp = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].xp
            }
        }
//-
//USER
        const JadiUser = (userid, sender, age, time, serials) => {
            const obj = { id: userid, name: sender, age: age, time: time, serial: serials }
            user.push(obj)
            fs.writeFileSync('./database/user.json', JSON.stringify(user))
        }
        const bikinSerial = (size) => {
            return crypto.randomBytes(size).toString('hex').slice(0, size)
        }
//-
//LEVELING
        const getLevelingLevel = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].level
            }
        }

        const getLevelingId = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].id
            }
        }

        const addLevelingXp = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].xp += amount
                fs.writeFileSync('./database/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingLevel = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].level += amount
                fs.writeFileSync('./database/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingId = (sender) => {
            const obj = {id: sender, xp: 1, level: 1}
            _level.push(obj)
            fs.writeFileSync('./database/level.json', JSON.stringify(_level))
        }
//-
//GET LIMIT
        const getLimit = (sender) => {
        	let position = false
              Object.keys(limit).forEach ((i) => {
              	if (limit[position].id === sender) {
              	   position = i
                  }
              })
             if (position !== false) {
                return limit[position].limit
            }
        }
//-
//ADD ATM
        const addATM = (sender) => {
        	const obj = {id: sender, uang : 0}
            uang.push(obj)
            fs.writeFileSync('./database/uang.json', JSON.stringify(uang))
        }
//-
//ADD KOIN
        const addKoinUser = (sender, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang += amount
                fs.writeFileSync('./database/uang.json', JSON.stringify(uang))
            }
        }
//-
//CHECK ATM
        const checkATMuser = (sender) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return uang[position].uang
            }
        }
//-
//BAYAR LIMIT
        const bayarLimit = (sender, amount) => {
        	let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit -= amount
                fs.writeFileSync('./database/limit.json', JSON.stringify(_limit))
            }
        }
//-
//CONFIRM LIMIT
        const confirmATM = (sender, amount) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang -= amount
                fs.writeFileSync('./database/uang.json', JSON.stringify(uang))
            }
        }
//-
//LIMIT ADD
            const limitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 1
                fs.writeFileSync('./database/limit.json', JSON.stringify(_limit))
            }
        }
//-
//SLEEP
const sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}
//-
//FUNCTION
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  return `${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik`
}
//-
//CONNECTION
async function starts() {
const dp = new WAConnection()
dp.logger.level = 'warn'
console.log(banner.string)
   dp.on('qr', qr => {
   qrcode.generate(qr, { small: true })
	console.log(color('(+)','white'), color('AbdillahGanz','red'), color('(+)','white'), color(' SQAN CODENYA','aqua'), color('SUBREK YT ItsmeAbdillah','yellow'))
})

	dp.on('credentials-updated', () => {
		fs.writeFileSync('./dpbot.json', JSON.stringify(dp.base64EncodedAuthInfo(), null, '\t'))
		info('2', 'info!')
	})
	fs.existsSync('./dpbot.json') && dp.loadAuthInfo('./dpbot.json')
	dp.on('connecting', () => {
		start('2', color('[ ! ]Scan Codenya Ngab','aqua'))
	})
	dp.on('open', () => {
		success('2', color('[ ! ]Tersambung','red'))
	})
	dp.connect({timeoutMs: 30*1000})
//-
//WELCOME & LEAVE
dp.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
            num = anu.participants[0]
            const mdata = await dp.groupMetadata(anu.jid)
            try {
                var pp_user = await dp.getProfilePicture(num)
            } catch (e) {
                var pp_user = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
            }
            if (anu.action == 'add') {
                ini_user = dp.contacts[num]
                ini_img = await getBuffer(`http://api.lolhuman.xyz/api/welcomeimage?apikey=${LolHuman}&img=${pp_user}&text=${ini_user.notify}`)
                group_info = await dp.groupMetadata(anu.jid)
                welkam = `Hai ${ini_user.notify}\n◪ Welcome in group:\n├─ ${mdata.subject}\n│\n├─ Intro dulu\n├─ ❏ Nama: \n├─ ❏ Umur: \n├─ ❏ Asal kota: \n├─ ❏ Kelas: \n├─ ❏ Jenis kelamin: \n└─ ❏ Nomor: ${num.replace('@s.whatsapp.net', '')}\nSemoga Betah yaa~~\n${ini_user.notify}`
                dp.sendMessage(anu.jid, ini_img, MessageType.image, { caption: welkam })
            }
            if (anu.action == 'remove') {
                ini_user = dp.contacts[num]
                ini_img = await getBuffer(`http://api.lolhuman.xyz/api/welcomeimage?apikey=${LolHuman}&img=${pp_user}&text=${ini_user.notify}`)
                out = `◪ Goodbye ${ini_user.notify}\n◪ Leave from group:\n${mdata.subject}\n│\n└─ ❏ Nomor: ${num.replace('@s.whatsapp.net', '')}\nGoodBye~~`
                dp.sendMessage(anu.jid, ini_img, MessageType.image, { caption: out })
            }
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
})
	dp.on('CB:Blocklist', json => {
		if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})
//-

//HARI & BULAN
var date = new Date();
        var tahun = date.getFullYear();
        var bulan1 = date.getMonth();
        var tanggal = date.getDate();
        var hari = date.getDay();
        var jam = date.getHours();
        var menit = date.getMinutes();
        var detik = date.getSeconds();
        var waktoo = date.getHours();
            switch(hari) {
                case 0: hari = "Minggu"; break;
                case 1: hari = "Senin"; break;
                case 2: hari = "Selasa"; break;
                case 3: hari = "Rabu"; break;
                case 4: hari = "Kamis"; break;
                case 5: hari = "Jum`at"; break;
                case 6: hari = "Sabtu"; break;
            }
            switch(bulan1) {
                case 0: bulan1 = "Januari"; break;
                case 1: bulan1 = "Februari"; break;
                case 2: bulan1 = "Maret"; break;
                case 3: bulan1 = "April"; break;
                case 4: bulan1 = "Mei"; break;
                case 5: bulan1 = "Juni"; break;
                case 6: bulan1 = "Juli"; break;
                case 7: bulan1 = "Agustus"; break;
                case 8: bulan1 = "September"; break;
                case 9: bulan1 = "Oktober"; break;
                case 10: bulan1 = "November"; break;
                case 11: bulan1 = "Desember"; break;
            }
            var tampilTanggal = "" + hari + ", " + tanggal + " " + bulan1 + " " + tahun;
            var tampilWaktu = "" + "Jam : " + jam + ":" + menit + ":" + detik + " Wib";
//-
//ANTIDELETE
	dp.on('message-update', async (dap) => {
		try {
	    const from = dap.key.remoteJid
		const messageStubType = WA_MESSAGE_STUB_TYPES[dap.messageStubType] || 'MESSAGE'
		const dataRevoke = JSON.parse(fs.readFileSync('./src/gc-revoked.json'))
		const dataCtRevoke = JSON.parse(fs.readFileSync('./src/ct-revoked.json'))
		const dataBanCtRevoke = JSON.parse(fs.readFileSync('./src/ct-revoked-banlist.json'))
		const sender = dap.key.fromMe ? dp.user.jid : dap.key.remoteJid.endsWith('@g.us') ? dap.participant : dap.key.remoteJid
		const isRevoke = dap.key.remoteJid.endsWith('@s.whatsapp.net') ? true : dap.key.remoteJid.endsWith('@g.us') ? dataRevoke.includes(from) : false
		const isCtRevoke = dap.key.remoteJid.endsWith('@g.us') ? true : dataCtRevoke.data ? true : false
		const isBanCtRevoke = dap.key.remoteJid.endsWith('@g.us') ? true : !dataBanCtRevoke.includes(sender) ? true : false
		if (messageStubType == 'REVOKE') {
			console.log(`Status untuk grup : ${!isRevoke}\nStatus semua kontak : ${!isCtRevoke}\nStatus kontak dikecualikan : ${!isBanCtRevoke}`)
			if (!isRevoke) return
			if (!isCtRevoke) return
			if (!isBanCtRevoke) return
			const from = dap.key.remoteJid
			const isGroup = dap.key.remoteJid.endsWith('@g.us') ? true : false
			let int
			let infoMSG = JSON.parse(fs.readFileSync('./src/msg.data.json'))
			const id_deleted = dap.key.id
			const conts = !dap.key.fromMe ? dp.user.jid : dp.contacts[sender] || { notify: jid.replace(/@.+/, '') }
			const pushname = !dap.key.fromMe ? dp.user.name : conts.notify || conts.vname || conts.name || '-'
			const opt4tag = {
				contextInfo: { mentionedJid: [sender] }
			}
			for (let i = 0; i < infoMSG.length; i++) {
				if (infoMSG[i].key.id == id_deleted) {
					const dataInfo = infoMSG[i]
					const type = Object.keys(infoMSG[i].message)[0]
					const timestamp = infoMSG[i].messageTimestamp
					int = {
						no: i,
						type: type,
						timestamp: timestamp,
						data: dataInfo
					}
				}
			}
			const dpuhyex = Number(int.no)
			const body = int.type == 'conversation' ? infoMSG[dpuhyex].message.conversation : int.type == 'extendedTextMessage' ? infoMSG[dpuhyex].message.extendedTextMessage.text : int.type == 'imageMessage' ? infoMSG[dpuhyex].message.imageMessage.caption : int.type == 'stickerMessage' ? 'Sticker' : int.type == 'audioMessage' ? 'Audio' : int.type == 'videoMessage' ? infoMSG[dpuhyex].videoMessage.caption : infoMSG[dpuhyex]
			const mediaData = int.type === 'extendedTextMessage' ? JSON.parse(JSON.stringify(int.data).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : int.data
			var itsme = `${numbernye}@s.whatsapp.net`
				var split = `${fake}`
				var selepbot72 = {
					contextInfo: {
						participant: itsme,
						quotedMessage: {
							extendedTextMessage: {
								text: split,
							}
						}
					}
				}
			if (int.type == 'conversation' || int.type == 'extendedTextMessage') {
				const strConversation = `		 「 ANTI-DELETE 」

- Nama : ${pushname} 
- Nomer : ${sender.replace('@s.whatsapp.net', '')}
- Tipe : Text
- Waktu : ${moment.unix(int.timestamp).format('HH:mm:ss')}
- Tanggal : ${moment.unix(int.timestamp).format('DD/MM/YYYY')}
- Pesan : ${body ? body : '-'}`
				dp.sendMessage(from, strConversation, MessageType.text, selepbot72)
			} else if (int.type == 'stickerMessage') {
				var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					const pingbro23 = {
						contextInfo: {
							participant: itsme,
							quotedMessage: {
								extendedTextMessage: {
									text: split,
								}
							}
						}
					}
				const filename = `${sender.replace('@s.whatsapp.net', '')}-${moment().unix()}`
				const savedFilename = await dp.downloadAndSaveMediaMessage(int.data, `./media/sticker/${filename}`);
				const strConversation = `		 「 ANTI-DELETE 」

- Nama : ${pushname} 
- Nomer : ${sender.replace('@s.whatsapp.net', '')}
- Tipe : Sticker
- Waktu : ${moment.unix(int.timestamp).format('HH:mm:ss')}
- Tanggal : ${moment.unix(int.timestamp).format('DD/MM/YYYY')}`

				const buff = fs.readFileSync(savedFilename)
				dp.sendMessage(from, strConversation, MessageType.text, opt4tag)
				dp.sendMessage(from, buff, MessageType.sticker, pingbro23)
				fs.unlinkSync(savedFilename)

			} else if (int.type == 'imageMessage') {
				var itsme = `${numbernye}@s.whatsapp.net`
					var split = `${fake}`
					const pingbro22 = {
						contextInfo: {
							participant: itsme,
							quotedMessage: {
								extendedTextMessage: {
									text: split,
								}
							}
						}
					}
				const filename = `${sender.replace('@s.whatsapp.net', '')}-${moment().unix()}`
				const savedFilename = await dp.downloadAndSaveMediaMessage(int.data, `./media/revoke/${filename}`);
				const buff = fs.readFileSync(savedFilename)
				const strConversation = `	 「 ANTI-DELETE 」

- Nama : ${pushname} 
- Nomer : ${sender.replace('@s.whatsapp.net', '')}
- Tipe : Image
- Waktu : ${moment.unix(int.timestamp).format('HH:mm:ss')}
- Tanggal : ${moment.unix(int.timestamp).format('DD/MM/YYYY')}
- Pesan : ${body ? body : '-'}\`\`\``
				dp.sendMessage(from, buff, MessageType.image, { contextInfo: { mentionedJid: [sender] }, caption: strConversation })
				fs.unlinkSync(savedFilename)
			}
		}
	} catch (e) {
		console.log('Message : %s', color(e, 'green'))
	}
})
dp.on('message-new', async (dap) => {
	try {
		if (!dap.message) return
		if (dap.key && dap.key.remoteJid == 'status@broadcast') return
		let infoMSG = JSON.parse(fs.readFileSync('./src/msg.data.json'))
		infoMSG.push(JSON.parse(JSON.stringify(dap)))
		fs.writeFileSync('./src/msg.data.json', JSON.stringify(infoMSG, null, 2))
		const urutan_pesan = infoMSG.length
		if (urutan_pesan === 5000) {
			infoMSG.splice(0, 4300)
			fs.writeFileSync('./src/msg.data.json', JSON.stringify(infoMSG, null, 2))
		}
			if (!dap.message) return
			if (dap.key && dap.key.remoteJid == 'status@broadcast') return
			if (!dap.key.fromMe && banChats === true) return
			if (!publik) {
  }
			global.prefix
			global.blocked
			const from = dap.key.remoteJid
			const content = JSON.stringify(dap.message)
			const type = Object.keys(dap.message)[0]
			//-
			//MULTI PREFIX -BY TANAKA
			const cmd = (type === 'conversation' && dap.message.conversation) ? dap.message.conversation : (type == 'imageMessage') && dap.message.imageMessage.caption ? dap.message.imageMessage.caption : (type == 'videoMessage') && dap.message.videoMessage.caption ? dap.message.videoMessage.caption : (type == 'extendedTextMessage') && dap.message.extendedTextMessage.text ? dap.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
			const prefix = /^[°•π÷×¶∆£¢€¥®™✓=|~zZ+×_*!#$%^&./\\©^]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™✓=|~zZ+×_*!#$,|`÷?;:%abcdefghijklmnopqrstuvwxyz%^&./\\©^]/gi) : '-'
			//-
			//WAKTU
			const date = new Date().toLocaleDateString()
			const time = moment.tz('Asia/Jakarta').format('HH:mm:ss')
			const wita = moment.tz('Asia/Makassar').format('HH:mm:ss')
			const wit = moment.tz('Asia/Jayapura').format('HH:mm:ss')
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
            body = (type === 'conversation' && dap.message.conversation.startsWith(prefix)) ? dap.message.conversation : (type == 'imageMessage') && dap.message.imageMessage.caption.startsWith(prefix) ? dap.message.imageMessage.caption : (type == 'videoMessage') && dap.message.videoMessage.caption.startsWith(prefix) ? dap.message.videoMessage.caption : (type == 'extendedTextMessage') && dap.message.extendedTextMessage.text.startsWith(prefix) ? dap.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? dap.message.conversation : (type === 'extendedTextMessage') ? dap.message.extendedTextMessage.text : ''
			var pes = (type === 'conversation' && dap.message.conversation) ? dap.message.conversation : (type == 'imageMessage') && dap.message.imageMessage.caption ? dap.message.imageMessage.caption : (type == 'videoMessage') && dap.message.videoMessage.caption ? dap.message.videoMessage.caption : (type == 'extendedTextMessage') && dap.message.extendedTextMessage.text ? dap.message.extendedTextMessage.text : ''
			const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			var Link = (type === 'conversation' && dap.message.conversation) ? dap.message.conversation : (type == 'imageMessage') && dap.message.imageMessage.caption ? dap.message.imageMessage.caption : (type == 'videoMessage') && dap.message.videoMessage.caption ? dap.message.videoMessage.caption : (type == 'extendedTextMessage') && dap.message.extendedTextMessage.text ? dap.message.extendedTextMessage.text : ''
			const messagesLink = Link.slice(0).trim().split(/ +/).shift().toLowerCase()
			var tas = (type === 'conversation' && dap.message.conversation) ? dap.message.conversation : (type == 'imageMessage') && dap.message.imageMessage.caption ? dap.message.imageMessage.caption : (type == 'videoMessage') && dap.message.videoMessage.caption ? dap.message.videoMessage.caption : (type == 'extendedTextMessage') && dap.message.extendedTextMessage.text ? dap.message.extendedTextMessage.text : ''
			const mesejAnti = tas.slice(0).trim().split(/ +/).shift().toLowerCase()
			const RAM = `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB`
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)
			const tescuk = ["0@s.whatsapp.net"]
			const isGroup = from.endsWith('@g.us')
			const botNumber = dp.user.jid
			const sender = isGroup ? dap.participant : dap.key.remoteJid
			pushname = dp.contacts[sender] != undefined ? dp.contacts[sender].vname || dp.contacts[sender].notify : undefined
			//-
			//SECURITY
			const groupMetadata = isGroup ? await dp.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupDesc = isGroup ? groupMetadata.desc : ''
            const isEventon = isGroup ? event.includes(from) : false
            const isLevelingOn = isGroup ? _leveling.includes(from) : false
			const isWelkom = isGroup ? welkom.includes(from) : false
			const isNsfw = isGroup ? nsfw.includes(from) : false
			const isSimi = isGroup ? samih.includes(from) : false
			const isAntiLink = isGroup ? antilink.includes(from) : false
			const isAntiVirtex = isGroup ? antivirtex.includes(from) : false
			const isBadWord = isGroup ? badword.includes(from) : false
			const isUser = user.includes(sender)
			const isBanned = ban.includes(sender)
			const isImage = type === 'imageMessage'
			const sekarang = new Date().getTime();
			//-
			//WAKTU
			var ase = new Date();
                        var waktoo = ase.getHours();
                        switch(waktoo){
                case 0: waktoo = "Waktu Tengah Malam🌚 - Tidur Kak :)"; break;
                case 1: waktoo = "Waktu Tengah Malam🌚 - Tidur Kak :)"; break;
                case 2: waktoo = "Waktu Dini Hari🌒 - Tidur Kak :)"; break;
                case 3: waktoo = "Waktu Dini Hari🌓 - Tidur Kak :)"; break;
                case 4: waktoo = "Subuh🌔"; break;
                case 5: waktoo = "Subuh🌔"; break;
                case 6: waktoo = "Selamat Pagi kak🌝🌝"; break;
                case 7: waktoo = "Selamat Pagi kak🌝🌝"; break;
                case 8: waktoo = "Selamat Pagi kak🌝🌝"; break;
                case 9: waktoo = "Selamat Pagi kak🌝 kak🌝"; break;
                case 10: waktoo = "Selamat Pagi kak🌝"; break;
                case 11: waktoo = "Selamat Siang Kak🌞\n - Jangan Lupa Shalat Dzuhur"; break;
                case 12: waktoo = "Selamat Siang Kak🌞\n - Jangan Lupa Shalat Dzuhur"; break;
                case 13: waktoo = "Selamat Siang Kak🌞\n - Jangan Lupa Shalat Dzuhur"; break;
                case 14: waktoo = "Selamat Siang Kak🌞\n - Jangan Lupa Beristirahat :)"; break;
                case 15: waktoo = "Selamat Sore Kak🌝\n -  Jangan Lupa Mandi Dan shalat ashar"; break;
                case 16: waktoo = "Selamat Sore Kak🌝\n  - Jangan Lupa Mandi Dan shalat ashar"; break;
                case 17: waktoo = "Selamat Sore Kak🌖\n - Menjelang Malam🌚"; break;
                case 18: waktoo = "Waktu Magrib🌘\n - Jangan Lupa Shalat Magrib Kak"; break;
                case 19: waktoo = "Waktu Magrib🌚"; break;
                case 20: waktoo = "Selamat Malam🌚"; break;
                case 21: waktoo = "Selamat Malam🌚"; break;
                case 22: waktoo = "Selamat Malam🌚\n - Jangan Lupa Beristirahat & Jangan Gadang"; break;
                case 23: waktoo = "Tengah Malam🌚 \n - Tidur Kak, Ga baik bergadang :)"; break;
            }
            var tampilHari = "" + waktoo;
            //-
            //WAKTU BUAT FAKEREPLY
            var ase = new Date();
                        var waktoonyabro = ase.getHours();
                        switch(waktoonyabro){
                case 0: waktoonyabro = `Selamat Malam 🌛`; break;
                case 1: waktoonyabro = `Selamat Malam 🌛`; break;
                case 2: waktoonyabro = `Selamat Malam 🌛`; break;
                case 3: waktoonyabro = `Selamat Pagi ✨`; break;
                case 4: waktoonyabro = `Selamat Pagi ✨`; break;
                case 5: waktoonyabro = `Selamat Pagi ✨`; break;
                case 6: waktoonyabro = `Selamat Pagi ✨`; break;
                case 7: waktoonyabro = `Selamat Pagi ✨`; break;
                case 8: waktoonyabro = `Selamat Pagi ✨`; break;
                case 9: waktoonyabro = `Selamat Pagi ✨`; break;
                case 10: waktoonyabro = `Selamat Pagi ✨`; break;
                case 11: waktoonyabro = `Selamat Siang 🔥`; break;
                case 12: waktoonyabro = `Selamat Siang 🔥`; break;
                case 13: waktoonyabro = `Selamat Siang 🔥`; break;
                case 14: waktoonyabro = `Selamat Siang 🔥`; break;
                case 15: waktoonyabro = `Selamat Sore 🌹`; break;
                case 16: waktoonyabro = `Selamat Sore 🌹`; break;
                case 17: waktoonyabro = `Selamat Sore 🌹`; break;
                case 18: waktoonyabro = `Selamat Malam 🌛`; break;
                case 19: waktoonyabro = `Selamat Malam 🌛`; break;
                case 20: waktoonyabro = `Selamat Malam 🌛`; break;
                case 21: waktoonyabro = `Selamat Malam 🌛`; break;
                case 22: waktoonyabro = `Selamat Malam 🌛`; break;
                case 23: waktoonyabro = `Selamat Malam 🌛`; break;
            }
            var YahahaHayyuk = "" + waktoonyabro;
            //-
			//FAKE REPLY
			const freply = { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "6283136505591-1614953337@g.us" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/png", "caption": `${YahahaHayyuk}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('./lib/logo.jpeg')} } }
			const ftoko = { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "productMessage": { "product": { "productImage":{ "mimetype": "image/jpeg", "jpegThumbnail": fs.readFileSync('./lib/logo.jpeg') }, "title": `${YahahaHayyuk}`, "productImageCount": 9999 }, "businessOwnerJid": `${nomerlu}@s.whatsapp.net`}}}
			const fkontak = { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: '16504228206@s.whatsapp.net' } : {}) }, message: { "contactMessage": { "displayName": `${YahahaHayyuk}`, "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:XL;${YahahaHayyuk},;;;\nFN:${YahahaHayyuk},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, "jpegThumbnail": fs.readFileSync('./lib/logo.jpeg')}}}
//-
//SOTOY
        const sotoy = [
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍇 : 🍇',
		'🍊 : 🍋 : 🔔',
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🔔 : 🔔 : 🔔',
		'🍒 : 🍒 : 🍒',
		'🍌 : 🍌 : 🍌'
		]
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				dp.sendMessage(from, teks, text, {sendEphemeral: true, thumbnail: fs.readFileSync('./lib/logo.jpeg', 'base64'), quoted: ftoko})
			}
			const sendMess = (hehe, teks) => {
				dp.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? dp.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : dp.sendMessage(from, teks.trim(), extendedText, {quoted: dap, contextInfo: {"mentionedJid": memberr}})
			}
			const sendImage = (teks) => {
		    dp.sendMessage(from, teks, image, {quoted:dap})
		    }
		    const costum = (pesan, tipe, target, target2) => {
			dp.sendMessage(from, pesan, tipe, {sendEphemeral: true, thumbnail: fs.readFileSync('./lib/logo.jpeg', 'base64'), quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target2}` }}})
			}
		    const sendPtt = (teks) => {
		    dp.sendMessage(from, audio, mp3, {quoted:dap})
		    }
		    const dappauhuy = (pesan, tipe, target, target2) => {
		    dp.sendMessage(from, pesan, tipe, { "contextInfo": {mentionedJid: [sender], "forwardingScore": 999,"isForwarded": true}, quoted: { "key": { "participant": `${target}`, "remoteJid": "393470602054-1351628616@g.us", "fromMe": false, "id": "B391837A58338BA8186C47E51FFDFD4A" }, "message": { "documentMessage": { "jpegThumbnail": fs.readFileSync('./lib/logo.jpeg'), "mimetype": "application/octet-stream", "title": `${target2}`, "fileLength": "36", "pageCount": 0, "fileName": `${target2}` }}, "messageTimestamp": "1614069378", "status": "PENDING"}})
		    }
//-
//ROLE
		const levelRole = getLevelingLevel(sender)
          var role = 'Newbie ㋡'
        if (levelRole <= 2) {
            role = 'Newbie ㋡'
        } else if (levelRole <= 4) {
            role = 'Beginner Grade 1 ⚊¹'
        } else if (levelRole <= 6) {
            role = 'Beginner Grade 2 ⚊²'
        } else if (levelRole <= 8) {
            role = 'Beginner Grade 3 ⚊³'
        } else if (levelRole <= 10) {
            role = 'Beginner Grade 4 ⚊⁴'
        } else if (levelRole <= 12) {
            role = 'Private Grade 1 ⚌¹'
        } else if (levelRole <= 14) {
            role = 'Private Grade 2 ⚌²'
        } else if (levelRole <= 16) {
            role = 'Private Grade 3 ⚌³'
        } else if (levelRole <= 18) {
            role = 'Private Grade 4 ⚌⁴'
        } else if (levelRole <= 20) {
            role = 'Private Grade 5 ⚌⁵'
        } else if (levelRole <= 22) {
            role = 'Corporal Grade 1 ☰¹'
        } else if (levelRole <= 24) {
            role = 'Corporal Grade 2 ☰²'
        } else if (levelRole <= 26) {
            role = 'Corporal Grade 3 ☰³'
        } else if (levelRole <= 28) {
            role = 'Corporal Grade 4 ☰⁴'
        } else if (levelRole <= 30) {
            role = 'Corporal Grade 5 ☰⁵'
        } else if (levelRole <= 32) {
            role = 'Sergeant Grade 1 ≣¹'
        } else if (levelRole <= 34) {
            role = 'Sergeant Grade 2 ≣²'
        } else if (levelRole <= 36) {
            role = 'Sergeant Grade 3 ≣³'
        } else if (levelRole <= 38) {
            role = 'Sergeant Grade 4 ≣⁴'
        } else if (levelRole <= 40) {
            role = 'Sergeant Grade 5 ≣⁵'
        } else if (levelRole <= 42) {
            role = 'Staff Grade 1 ﹀¹'
        } else if (levelRole <= 44) {
            role = 'Staff Grade 2 ﹀²'
        } else if (levelRole <= 46) {
            role = 'Staff Grade 3 ﹀³'
        } else if (levelRole <= 48) {
            role = 'Staff Grade 4 ﹀⁴'
        } else if (levelRole <= 50) {
            role = 'Staff Grade 5 ﹀⁵'
        } else if (levelRole <= 52) {
            role = 'Sergeant Grade 1 ︾¹'
        } else if (levelRole <= 54) {
            role = 'Sergeant Grade 2 ︾²'
        } else if (levelRole <= 56) {
            role = 'Sergeant Grade 3 ︾³'
        } else if (levelRole <= 58) {
            role = 'Sergeant Grade 4 ︾⁴'
        } else if (levelRole <= 60) {
            role = 'Sergeant Grade 5 ︾⁵'
        } else if (levelRole <= 62) {
            role = '2nd Lt. Grade 1 ♢¹ '
        } else if (levelRole <= 64) {
            role = '2nd Lt. Grade 2 ♢²'
        } else if (levelRole <= 66) {
            role = '2nd Lt. Grade 3 ♢³'
        } else if (levelRole <= 68) {
            role = '2nd Lt. Grade 4 ♢⁴'
        } else if (levelRole <= 70) {
            role = '2nd Lt. Grade 5 ♢⁵'
        } else if (levelRole <= 72) {
            role = '1st Lt. Grade 1 ♢♢¹'
        } else if (levelRole <= 74) {
            role = '1st Lt. Grade 2 ♢♢²'
        } else if (levelRole <= 76) {
            role = '1st Lt. Grade 3 ♢♢³'
        } else if (levelRole <= 78) {
            role = '1st Lt. Grade 4 ♢♢⁴'
        } else if (levelRole <= 80) {
            role = '1st Lt. Grade 5 ♢♢⁵'
        } else if (levelRole <= 82) {
            role = 'Major Grade 1 ✷¹'
        } else if (levelRole <= 84) {
            role = 'Major Grade 2 ✷²'
        } else if (levelRole <= 86) {
            role = 'Major Grade 3 ✷³'
        } else if (levelRole <= 88) {
            role = 'Major Grade 4 ✷⁴'
        } else if (levelRole <= 90) {
            role = 'Major Grade 5 ✷⁵'
        } else if (levelRole <= 92) {
            role = 'Colonel Grade 1 ✷✷¹'
        } else if (levelRole <= 94) {
            role = 'Colonel Grade 2 ✷✷²'
        } else if (levelRole <= 96) {
            role = 'Colonel Grade 3 ✷✷³'
        } else if (levelRole <= 98) {
            role = 'Colonel Grade 4 ✷✷⁴'
        } else if (levelRole <= 100) {
            role = 'Colonel Grade 5 ✷✷⁵'
        } else if (levelRole <= 102) {
            role = 'Brigadier Early ✰'
        } else if (levelRole <= 104) {
            role = 'Brigadier Silver ✩'
        } else if (levelRole <= 106) {
            role = 'Brigadier gold ✯'
        } else if (levelRole <= 108) {
            role = 'Brigadier Platinum ✬'
        } else if (levelRole <= 110) {
            role = 'Brigadier Diamond ✪'
        } else if (levelRole <= 112) {
            role = 'Major General Early ✰'
        } else if (levelRole <= 114) {
            role = 'Major General Silver ✩'
        } else if (levelRole <= 116) {
            role = 'Major General gold ✯'
        } else if (levelRole <= 118) {
            role = 'Major General Platinum ✬'
        } else if (levelRole <= 120) {
            role = 'Major General Diamond ✪'
        } else if (levelRole <= 122) {
            role = 'Lt. General Early ✰'
        } else if (levelRole <= 124) {
            role = 'Lt. General Silver ✩'
        } else if (levelRole <= 126) {
            role = 'Lt. General gold ✯'
        } else if (levelRole <= 128) {
            role = 'Lt. General Platinum ✬'
        } else if (levelRole <= 130) {
            role = 'Lt. General Diamond ✪'
        } else if (levelRole <= 132) {
            role = 'General Early ✰'
        } else if (levelRole <= 134) {
            role = 'General Silver ✩'
        } else if (levelRole <= 136) {
            role = 'General gold ✯'
        } else if (levelRole <= 138) {
            role = 'General Platinum ✬'
        } else if (levelRole <= 140) {
            role = 'General Diamond ✪'
        } else if (levelRole <= 142) {
            role = 'Commander Early ★'
        } else if (levelRole <= 144) {
            role = 'Commander Intermediate ⍣'
        } else if (levelRole <= 146) {
            role = 'Commander Elite ≛'
        } else if (levelRole <= 148) {
            role = 'The Commander Hero ⍟'
        } else if (levelRole <= 152) {
            role = 'Legends 忍'
        } else if (levelRole <= 154) {
            role = 'Legends 忍'
        } else if (levelRole <= 156) {
            role = 'Legends 忍'
        } else if (levelRole <= 158) {
            role = 'Legends 忍'
        } else if (levelRole <= 160) {
            role = 'Legends 忍'
        } else if (levelRole <= 162) {
            role = 'Legends 忍'
        } else if (levelRole <= 164) {
            role = 'Legends 忍'
        } else if (levelRole <= 166) {
            role = 'Legends 忍'
        } else if (levelRole <= 168) {
            role = 'Legends 忍'
        } else if (levelRole <= 170) {
            role = 'Legends 忍'
        } else if (levelRole <= 172) {
            role = 'Legends 忍'
        } else if (levelRole <= 174) {
            role = 'Legends 忍'
        } else if (levelRole <= 176) {
            role = 'Legends 忍'
        } else if (levelRole <= 178) {
            role = 'Legends 忍'
        } else if (levelRole <= 180) {
            role = 'Legends 忍'
        } else if (levelRole <= 182) {
            role = 'Legends 忍'
        } else if (levelRole <= 184) {
            role = 'Legends 忍'
        } else if (levelRole <= 186) {
            role = 'Legends 忍'
        } else if (levelRole <= 188) {
            role = 'Legends 忍'
        } else if (levelRole <= 190) {
            role = 'Legends 忍'
        } else if (levelRole <= 192) {
            role = 'Legends 忍'
        } else if (levelRole <= 194) {
            role = 'Legends 忍'
        } else if (levelRole <= 196) {
            role = 'Legends 忍'
        } else if (levelRole <= 198) {
            role = 'Legends 忍'
        } else if (levelRole <= 200) {
            role = 'Legends 忍'
        } else if (levelRole <= 1243) {
   	         role = 'Legends 忍'
   	     }
   
			var premi = 'User 🏅'
			
			if (dap.key.fromMe) {
				premi = 'Owner ⚔️'
		    }
		
		     var asu = `${limitawal}`
//-
//LEVELING
            if (isGroup && isUser && isLevelingOn) {
            const currentLevel = getLevelingLevel(sender)
            const checkId = getLevelingId(sender)
            try {
                if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
                const amountXp = Math.floor(Math.random() * 10) + 500
                const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1)
                const getLevel = getLevelingLevel(sender)
                addLevelingXp(sender, amountXp)
                if (requiredXp <= getLevelingXp(sender)) {
                    addLevelingLevel(sender, 1)
                    await reply(dpuhy.levelup(pushname, sender, getLevelingXp, getLevel, getLevelingLevel))
                }
            } catch (err) {
                console.error(err)
            }
        }
//-
//CHECK LIMIT
          const checkLimit = (sender) => {
			let found = false
			for (let lmt of _limit) {
			if (lmt.id === sender) {
			let limitCounts = limitawal - lmt.limit
			if (limitCounts <= 0) return dp.sendMessage(from,`Limit request anda sudah habis\n`, text, {quoted: fkontak})
			dp.sendMessage(from, `
「 ❗ 」Limit Count
Sisa Limit Anda : ${limitCounts}

NOTE : Untuk Mendapatkan Limit Bisa Lewat Naik Level Di Group Atau Buy limit.`, text, { quoted : fkontak})
			found = true 
			}
		}
			if (found === false) {
			let obj = { id: sender, limit: 0 }
			_limit.push(obj)
			fs.writeFileSync('./database/limit.json', JSON.stringify(_limit))
			dp.sendMessage(from, `limit anda : ${limitCounts}`, text, { quoted : fkontak})
			}
		} 
//-
//LIMIT
           const isLimit = (sender) =>{ 
		      let position = false
              for (let i of _limit) {
              if (i.id === sender) {
              	let limits = i.limit
              if (limits >= limitawal ) {
              	  position = true
                    dp.sendMessage(from, dpuhy.limitend(pushname), text, {quoted: fkontak})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 1 }
                _limit.push(obj)
                fs.writeFileSync('./database/limit.json',JSON.stringify(_limit))
           return false
       }
     }
//-
//TEXT
if (budy.includes(`Prefix`)) {
           reply(`「 MULTI PREFIX 」`)
           }
if (budy.includes(`prefix`)) {
           reply(`「 MULTI PREFIX 」`)
           }
if (budy.includes(`dogestick`)) { //GABUT DOANG (no prefix)
kntl = await getBuffer(`https://api.lolhuman.xyz/api/sticker/anjing?apikey=${LolHuman}`)
dp.sendMessage(from, kntl, sticker, {quoted: freply})
           }
//-
//ATM
            if (isGroup ) {
            const checkATM = checkATMuser(sender)
            try {
                if (checkATM === undefined) addATM(sender)
                const uangsaku = Math.floor(Math.random() * 10) + 90
                addKoinUser(sender, uangsaku)
            } catch (err) {
                console.error(err)
            }
        }
        
//-
//ANTILINK
                if (messagesC.match("://chat.whatsapp.com/")){
		        if (!isGroup) return
		        if (!isAntiLink) return
		        if (dap.key.fromMe) return reply('karena kamu adalah owner, bot tidak akan kick kamu')
		        dp.updatePresence(from, Presence.composing)
		        if (messagesC.includes("#izinadmin")) return reply("#izinadmin diterima")
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        reply(`Link Terdeteksi maaf ${sender.split("@")[0]} anda akan di kick dari group 3 detik lagi`)
		        setTimeout( () => {
		        dp.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
		        }, 3000)
		        setTimeout( () => {
		        dp.updatePresence(from, Presence.composing)
		        reply("1detik")
		        }, 2000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("2detik")
		        }, 1000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("3detik")
		        }, 0)
	            }
//-
//ANTIVIRTEX
	            if (messagesC.match("ผิดุท้่เึางืผิดุท้่เึาง")){
		        if (!isGroup) return
		        if (!isAntiVirtex) return
		        if (dap.key.fromMe) return reply('karena kamu adalah owner, bot tidak akan kick kamu')
		        dp.updatePresence(from, Presence.composing)
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        reply(`Virtex terdeteksi ${sender.split("@")[0]} anda akan di kick dari group 3 detik lagi`)
		        setTimeout( () => {
		        dp.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
		        }, 3000)
		        setTimeout( () => {
		        dp.updatePresence(from, Presence.composing)
		        reply("1detik")
		        }, 2000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("2detik")
		        }, 1000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("3detik")
		        }, 0)
	            }
	            if (messagesC.match("৭৭৭৭৭৭৭৭")){
		        if (!isGroup) return
		        if (!isAntiVirtex) return
		        if (dap.key.fromMe) return reply('karena kamu adalah owner, bot tidak akan kick kamu')
		        dp.updatePresence(from, Presence.composing)
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        reply(`Virtex terdeteksi ${sender.split("@")[0]} anda akan di kick dari group 3 detik lagi`)
		        setTimeout( () => {
		        dp.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
		        }, 3000)
		        setTimeout( () => {
		        dp.updatePresence(from, Presence.composing)
		        reply("1detik")
		        }, 2000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("2detik")
		        }, 1000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("3detik")
		        }, 0)
	            }
	            if (messagesC.match("๒๒๒๒๒๒๒๒")){
		        if (!isGroup) return
		        if (!isAntiVirtex) return
		        if (dap.key.fromMe) return reply('karena kamu adalah owner, bot tidak akan kick kamu')
		        dp.updatePresence(from, Presence.composing)
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        reply(`Virtex terdeteksi ${sender.split("@")[0]} anda akan di kick dari group 3 detik lagi`)
		        setTimeout( () => {
		        dp.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
		        }, 3000)
		        setTimeout( () => {
		        dp.updatePresence(from, Presence.composing)
		        reply("1detik")
		        }, 2000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("2detik")
		        }, 1000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("3detik")
		        }, 0)
	            }
	            if (messagesC.match("๑๑๑๑๑๑๑๑")){
		        if (!isGroup) return
		        if (!isAntiVirtex) return
		        if (dap.key.fromMe) return reply('karena kamu adalah owner, bot tidak akan kick kamu')
		        dp.updatePresence(from, Presence.composing)
		        var kic = `${sender.split("@")[0]}@s.whatsapp.net`
		        reply(`Virtex terdeteksi ${sender.split("@")[0]} anda akan di kick dari group 3 detik lagi`)
		        setTimeout( () => {
		        dp.groupRemove(from, [kic]).catch((e)=>{reply(`*ERR:* ${e}`)})
		        }, 3000)
		        setTimeout( () => {
		        dp.updatePresence(from, Presence.composing)
		        reply("1detik")
		        }, 2000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("2detik")
		        }, 1000)
		        setTimeout( () => {
			    dp.updatePresence(from, Presence.composing)
			    reply("3detik")
		        }, 0)
	            }
//-
//MEMBER LIMIT
           if (isGroup) {
					try {
						const getmemex = groupMembers.length	
					    if (getmemex <= memberlimit) {
						reply(`hmmm... sorry bro member minimal ${memberlimit} gw bakal keluar 5 detik lagi`)
						setTimeout( () => {
 	                           dp.groupLeave(from) 
 					   	}, 5000)
								setTimeout( () => {
								dp.updatePresence(from, Presence.composing)
								reply("1")
							}, 4000)
								setTimeout( () => {
								dp.updatePresence(from, Presence.composing)
								reply("2")
							}, 3000)
								setTimeout( () => {
								dp.updatePresence(from, Presence.composing)
								reply("3")
							}, 2000)
								setTimeout( () => {
								dp.updatePresence(from, Presence.composing)
								reply("4")
							}, 1000)
								setTimeout( () => {
								dp.updatePresence(from, Presence.composing)
								reply("5")
							}, 0)
					    }
		       } catch (err) { console.error(err)  }
 	       }
//-
//BADWORD
        if (bad.includes(messagesLink)) {
		if (!isGroup) return
		if (dap.key.fromMe) return reply('karena kamu adalah owner, bot tidak akan kick kamu')
		var Kick = `${sender.split("@")[0]}@s.whatsapp.net`
		setTimeout( () => {
		reply(`sᴀʏᴏɴᴀʀᴀ ʙᴇʙᴀɴ ɢʀᴜᴘ`)
		}, 100)
		setTimeout( () => {
		dp.groupRemove(from, [Kick]).catch((e) => {reply(`ERROR: ${e}`)}) 
		}, 10)
		setTimeout( () => {
		reply(`_「 ʙᴀᴅᴡᴏʀᴅ ᴅᴇᴛᴇᴄᴛᴇᴅ 」_\nᴍᴀᴀғ ${pushname} ᴀɴᴅᴀ ʙᴇʀʙɪᴄᴀʀᴀ ᴋᴏᴛᴏʀ!, ᴀɴᴅᴀ ꜱᴇɢᴇʀᴀ ᴅɪᴋɪᴄᴋ ᴅᴀʀɪ ɢʀᴜᴘ ${groupMetadata.subject}`)
		}, 0)
		}
			colors = ['red','white','black','blue','yellow','green']
			
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			
		    if (!isGroup && !isCmd) console.log(color(time, "white"), color("[ PRIVATE ]", "aqua"), color(budy, "white"), "from", color(sender.split('@')[0], "red"))
            if (isGroup && !isCmd) console.log(color([time], "white"), color("[  GROUP  ]", "aqua"), color(budy, "white"), "from", color(sender.split('@')[0], "red"), "in", color(groupName, "white"))
            if (!isGroup && isCmd) console.log(color([time], "white"), color("[ COMMAND ]", "aqua"), color(budy, "white"), "from", color(sender.split('@')[0], "red"))
            if (isGroup && isCmd) console.log(color([time], "white"), color("[ COMMAND ]", "aqua"), color(budy, "white"), "from", color(sender.split('@')[0], "red"), "in", color(groupName, "white"))
            //
            //FUNCTION TAKESTICK
            function addMetadata(packname, author) {
				if (!packname) packname = `@${namabot}`; if (!author) author = `${namaowner}`;	
				author = author.replace(/[^a-zA-Z0-9]/g, '');	
				let name = `${author}_${packname}`
				if (fs.existsSync(`./sticker/${name}.exif`)) return `./sticker/${name}.exif`
				const json = {	
					"sticker-pack-name": packname,
					"sticker-pack-publisher": author,
				}
				const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
				const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

				let len = JSON.stringify(json).length	
				let last	

				if (len > 256) {	
					len = len - 256	
					bytes.unshift(0x01)	
				} else {	
					bytes.unshift(0x00)	
				}	

				if (len < 16) {	
					last = len.toString(16)	
					last = "0" + len	
				} else {	
					last = len.toString(16)	
				}	

				const buf2 = Buffer.from(last, "hex")	
				const buf3 = Buffer.from(bytes)	
				const buf4 = Buffer.from(JSON.stringify(json))	

				const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

				fs.writeFile(`./sticker/${name}.exif`, buffer, (err) => {	
					return `./sticker/${name}.exif`	
				})	

			}
//-
//CASE
			switch(command) {
//==========================================BATES NGAB==========================================\\
//DASAR MENU
                case 'admin':
                case 'owner':
                case 'creator':
                case 'developer':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dp.sendMessage(from, {displayname: `${namaowner}ツ`, vcard: vcard1}, MessageType.contact, {quoted: freply})
                dp.sendMessage(from, 'Tuh nomer owner ku😎 jangan dispam yak',MessageType.text, {quoted: freply})
                break
                case 'limit':
                checkLimit(sender)
		        break
				case 'test':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
			    dp.sendMessage(from, 'Active',MessageType.text, {quoted: fkontak})
				break
				case 'speed':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                const processsTime = (timestamp, now) => {
                return moment.duration(now - moment(timestamp * 1000)).asSeconds()
                }
                reply(`Speed : ${processsTime(dap.messageTimestamp.low, moment())} _second_`)
                break
		        case 'ping':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				dp.sendMessage(from, 'Active',MessageType.text, {quoted: fkontak})
				break
				case 'donasi':
		        case 'donate':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				dp.sendMessage(from, donasi(), text, {quoted: fkontak})
				break
				case 'infoowner':
		        case 'infodeveloper':
		        case 'infopengembang':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				dp.sendMessage(from, infown(), text, {quoted: fkontak})
				break
				case 'bahasa':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				dp.sendMessage(from, bahasa(), text, {quoted: fkontak})
			    await limitAdd(sender)
				break
				case 'cheatgame':
			    dp.sendMessage(from, cheat(), text, {quoted: fkontak})
			    break
		        case 'kodenegara':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				dp.sendMessage(from, negara(), text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'report':
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`Apa yang mau direport ke owner?`)
				const pesan = body.slice(8)
				var nomor = dap.participant
				const teks1 = `[REPORT]\nNomor : @${nomor.split("@s.whatsapp.net")[0]}\nPesan : ${pesan}`
				var options = {
				text: teks1,
				contextInfo: {mentionedJid: [nomor]},
				}
				dp.sendMessage(`${nomerlu}@s.whatsapp.net`, options, text, {quoted: fkontak})
				reply('[❗] Masalah telah dilaporkan ke owner Bot, Laporan palsu/main - main akan ban permanent!!')
				break
				case 'saran':
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`Apa yang mau disarankan ke owner?`)
				const psn = body.slice(7)
				var nmr = dap.participant
				const tks1 = `[SARAN]\nNomor : @${nmr.split("@s.whatsapp.net")[0]}\nPesan : ${psn}`
				var options = {
				text: tks1,
				contextInfo: {mentionedJid: [nmr]},
				}
				dp.sendMessage(`${nomerlu}@s.whatsapp.net`, options, text, {quoted: fkontak})
				reply(`[❗] Saran telah dilaporkan ke owner Bot, Terimakasih ${pushname}`)
				break
				case 'verify':
				case 'daftar':
				if (isUser) return reply(dpuhy.rediregis())
				const SeriTod = bikinSerial(20)
				try {
				ppimg = await dp.getProfilePicture(`${sender.split('@')[0]}@c.us`)
				} catch {
				ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				imglu = 'http://www.dapoa-web.xyz/bgverify.jpeg' //ubah sesuka kamu, bisa upload di imgbb.com
				veri = sender
				user.push(sender)
				fs.writeFileSync('./database/user.json', JSON.stringify(user))
				JadiUser(sender, SeriTod)
				const kentod = 
`
╭─「 PENDAFTARAN USER 」
│${a}Pendaftaran Berhasil Dengan${a}
│${a}SN: ${SeriTod}${a}
│${a}Pada ${date} ${time}${a}
│${a}Nama: ${pushname}${a}
│${a}Nomor: wa.me/${sender.split("@")[0]}${a}
│${a}Untuk Menggunakan Bot${a}
│${a}Silahkan Kirim ${prefix}menu${a}
│${a}Total Pengguna: ${user.length} Orang${a}
╰─────────────────────────
`
                let buff = await getBuffer(`http://hadi-api.herokuapp.com/api/card/verify?nama=${encodeURI(pushname)}&member=${user.length}&seri=${SeriTod}&pp=${ppimg}&bg=${imglu}`)
                dp.sendMessage(from, buff, MessageType.image, {quoted: freply, caption: kentod, contextInfo: {"mentionedJid": [sender]}})
                break
		        case 'del':
		        case 'd':
		        case 'delete':
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				dp.deleteMessage(from, { id: dap.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true })
				break
				case 'info':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				me = dp.user
				uptime = process.uptime()
				teks = `INFO OWNER\nOwner bot : ${namaowner}ツ\nNo Owner : ${nomerlu}\nIg owner : ${igstah}\n━━━━━━━━━━━━━━━━━━━━\nINFO BOT\nNama bot : ${namabot}\nNomor bot : @${me.jid.split('@')[0]}\nPrefix : ${prefix}\nRam ${RAM}\nTotal block contact : ${blocked.length}\nThe bot is active on : ${kyun(uptime)}\nKetik : ${prefix}report _Untuk melaporkan admin bot melalui bot_\nKetik : ${prefix}owner untuk menghubungi admin bot kami.`
				buffer = await getBuffer(me.imgUrl)
				dp.sendMessage(from, buffer, image, {caption: teks, contextInfo:{mentionedJid: [me.jid]}})
				break
				case 'snk':
		        case 'peraturan':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
		        dp.sendMessage(from, snk(), text, {quoted: fkontak})
		        break
//==========================================BATES NGAB==========================================\\
//MENU
                case 'help':
		        case 'menu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}「 SELF BOT 」${a}

${a}◪ YOUR INFO${a}
${a}❒ Limit : ${asu} / Day${a}
${a}❒ Role : ${role}${a}
${a}❒ Status : ${premi}${a}
${a}❒ Nomer : ${sender.split("@")[0]}${a}

${a}Waktu : ${tampilHari} (WIB)${a}

${a}Jam : ${time} WIB⌚${a}
${a}Jam : ${wit} WIT⌚${a}
${a}Jam : ${wita} WITA⌚${a}

${a}Hari : ${tampilTanggal}${a}

${a}◪ MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}groupmenu${a}
${a}├─ ❏ ${prefix}ownermenu${a}
${a}├─ ❏ ${prefix}islammenu${a}
${a}├─ ❏ ${prefix}downloadmenu${a}
${a}├─ ❏ ${prefix}matematikamenu${a}
${a}├─ ❏ ${prefix}soundmenu${a}
${a}├─ ❏ ${prefix}makermenu${a}
${a}├─ ❏ ${prefix}stalkermenu${a}
${a}├─ ❏ ${prefix}imageeditmenu${a}
${a}├─ ❏ ${prefix}sertifikatmenu${a}
${a}├─ ❏ ${prefix}informationmenu${a}
${a}├─ ❏ ${prefix}othermenu${a}
${a}├─ ❏ ${prefix}funmenu${a}
${a}├─ ❏ ${prefix}mediamenu${a}
${a}├─ ❏ ${prefix}spammenu${a}
${a}├─ ❏ ${prefix}filmmenu${a}
${a}├─ ❏ ${prefix}toolsmenu${a}
${a}├─ ❏ ${prefix}animemenu${a}
${a}├─ ❏ ${prefix}searchingmenu${a}
${a}└─ ❏ ${prefix}beritamenu${a}

${a}${prefix}snk${a}
${a}${prefix}report${a} <text>
${a}${prefix}saran${a} <text>
${a}${prefix}infoowner${a}
${a}${prefix}info${a}
${a}${prefix}donasi${a}
${a}${prefix}ping${a}
${a}${prefix}speed${a}
${a}${prefix}owner${a}
${a}${prefix}test${a}
${a}${prefix}limit${a} (cek limit)

${a}❒ TQTQ ❒${a}
${a}AllahSWT${a}
${a}DappaUhuy${a}
${a}${namaowner}${a}
`

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'groupmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (!isGroup) return reply(dpuhy.groupo())
                dapuhy = `
${a}◪ GROUP MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}nobadword${a} 1/0
${a}├─ ❏ ${prefix}antilink${a} 1/0
${a}├─ ❏ ${prefix}antivirtex${a} 1/0
${a}├─ ❏ ${prefix}group${a} buka/tutup
${a}├─ ❏ ${prefix}setname${a} <text>
${a}├─ ❏ ${prefix}setdesc${a} <text>
${a}├─ ❏ ${prefix}promote${a} <tag>
${a}├─ ❏ ${prefix}demote${a} <tag>
${a}├─ ❏ ${prefix}kickall${a}
${a}├─ ❏ ${prefix}add${a} <nomer>
${a}├─ ❏ ${prefix}kick${a} <tag>
${a}├─ ❏ ${prefix}linkgc${a}
${a}├─ ❏ ${prefix}hidetag${a} <text>
${a}├─ ❏ ${prefix}mining${a}
${a}└─ ❏ ${prefix}level${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'ownermenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ OWNER MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}antidelete${a} aktif/mati
${a}├─ ❏ ${prefix}nsfw${a} 1/0
${a}├─ ❏ ${prefix}leveling${a} enable/disable
${a}├─ ❏ ${prefix}welcome${a} 1/0
${a}├─ ❏ ${prefix}event${a} 1/0
${a}├─ ❏ ${prefix}clone${a} <tag>
${a}├─ ❏ ${prefix}delete${a} <reply>
${a}├─ ❏ ${prefix}bc${a} <text>
${a}├─ ❏ ${prefix}bcgc${a} <text>
${a}├─ ❏ ${prefix}block${a} <tag>
${a}├─ ❏ ${prefix}unblock${a} <tag>
${a}├─ ❏ ${prefix}addvn${a} <reply audio>
${a}├─ ❏ ${prefix}getvn${a} <nama>
${a}├─ ❏ ${prefix}setthumb$a} <reply image>
${a}├─ ❏ ${prefix}listvn${a}
${a}├─ ❏ ${prefix}leave${a}
${a}├─ ❏ ${prefix}tagall${a}
${a}├─ ❏ ${prefix}clearall${a}
${a}├─ ❏ ${prefix}setprefix${a} <text>
${a}├─ ❏ ${prefix}resetlimit${a}
${a}├─ ❏ ${prefix}setlimit${a} <angka>
${a}├─ ❏ ${prefix}setmemlimit${a} <angka>
${a}├─ ❏ ${prefix}addbadword${a} <text>
${a}├─ ❏ ${prefix}delbadword${a} <text>
${a}├─ ❏ ${prefix}setppbot${a} <reply photo>
${a}├─ ❏ ${prefix}ban${a} <tag>
${a}└─ ❏ ${prefix}unban${a} <tag>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'islammenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ ISLAM MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}tahlil${a}
${a}├─ ❏ ${prefix}jadwalsholat${a}
${a}├─ ❏ ${prefix}kisahnabi${a}
${a}├─ ❏ ${prefix}ayatkursi${a}
${a}├─ ❏ ${prefix}doaharian${a}
${a}├─ ❏ ${prefix}niatsholat${a}
${a}└─ ❏ ${prefix}bacaansholat${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'downloadmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ DOWNLOAD MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}tiktoknowm${a} <url>
${a}├─ ❏ ${prefix}ytplay${a} <judul>
${a}├─ ❏ ${prefix}ytmp3${a} <url>
${a}├─ ❏ ${prefix}ytmp4${a} <url>
${a}├─ ❏ ${prefix}igvideo${a} <url>
${a}└─ ❏ ${prefix}igphoto${a} <url>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'matematikamenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ MATEMATIKA MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}perkalian${a} <angka*angka>
${a}├─ ❏ ${prefix}rumuspersegipanjang${a} <angka>
${a}├─ ❏ ${prefix}rumuspersegi${a} <angka>
${a}└─ ❏ ${prefix}kuadrat${a} <angka>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'soundmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ SOUND MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}sound${a}
${a}├─ ❏ ${prefix}sound1${a}
${a}├─ ❏ ${prefix}sound2${a}
${a}├─ ❏ ${prefix}sound3${a}
${a}├─ ❏ ${prefix}sound4${a}
${a}├─ ❏ ${prefix}sound5${a}
${a}├─ ❏ ${prefix}sound6${a}
${a}├─ ❏ ${prefix}sound7${a}
${a}├─ ❏ ${prefix}sound8${a}
${a}├─ ❏ ${prefix}sound9${a}
${a}└─ ❏ ${prefix}sound10${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'makermenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ MAKER MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}blackpink${a} <text>
${a}├─ ❏ ${prefix}neon${a} <text>
${a}├─ ❏ ${prefix}greenneon${a} <text>
${a}├─ ❏ ${prefix}advanceglow${a} <text>
${a}├─ ❏ ${prefix}futureneon${a} <text>
${a}├─ ❏ ${prefix}sandwriting${a} <text>
${a}├─ ❏ ${prefix}sandsummer${a} <text>
${a}├─ ❏ ${prefix}sandengraved${a} <text>
${a}├─ ❏ ${prefix}metaldark${a} <text>
${a}├─ ❏ ${prefix}neonlight${a} <text>
${a}├─ ❏ ${prefix}holographic${a} <text>
${a}├─ ❏ ${prefix}text1917${a} <text>
${a}├─ ❏ ${prefix}minion${a} <text>
${a}├─ ❏ ${prefix}deluxesilver${a} <text>
${a}├─ ❏ ${prefix}newyearcard${a} <text>
${a}├─ ❏ ${prefix}bloodfrosted${a} <text>
${a}├─ ❏ ${prefix}halloween${a} <text>
${a}├─ ❏ ${prefix}jokerlogo${a} <text>
${a}├─ ❏ ${prefix}fireworksparkle${a} <text>
${a}├─ ❏ ${prefix}natureleaves${a} <text>
${a}├─ ❏ ${prefix}bokeh${a} <text>
${a}├─ ❏ ${prefix}toxic${a} <text>
${a}├─ ❏ ${prefix}strawberry${a} <text>
${a}├─ ❏ ${prefix}box3d${a} <text>
${a}├─ ❏ ${prefix}roadwarning${a} <text>
${a}├─ ❏ ${prefix}breakwall${a} <text>
${a}├─ ❏ ${prefix}icecold${a} <text>
${a}├─ ❏ ${prefix}luxury${a} <text>
${a}├─ ❏ ${prefix}cloud${a} <text>
${a}├─ ❏ ${prefix}summersand${a} <text>
${a}├─ ❏ ${prefix}horrorblood${a} <text>
${a}├─ ❏ ${prefix}thunder${a} <text>
${a}├─ ❏ ${prefix}pornhub${a} <text>
${a}├─ ❏ ${prefix}avenger${a} <text>
${a}├─ ❏ ${prefix}space${a} <text>
${a}├─ ❏ ${prefix}ninjalogo${a} <text>
${a}├─ ❏ ${prefix}marvelstudio${a} <text>
${a}├─ ❏ ${prefix}lionlogo${a} <text>
${a}├─ ❏ ${prefix}wolflogo${a} <text>
${a}├─ ❏ ${prefix}steel3d${a} <text>
${a}├─ ❏ ${prefix}wallgravity${a} <text>
${a}├─ ❏ ${prefix}cup${a} <text>
${a}├─ ❏ ${prefix}cup1${a} <text>
${a}├─ ❏ ${prefix}woodenboard${a} <text>
${a}├─ ❏ ${prefix}woodheart${a} <text>
${a}├─ ❏ ${prefix}summer3d${a} <text>
${a}├─ ❏ ${prefix}love${a} <text>
${a}├─ ❏ ${prefix}wolfmetal${a} <text>
${a}├─ ❏ ${prefix}nature3d${a} <text>
${a}├─ ❏ ${prefix}underwater${a} <text>
${a}├─ ❏ ${prefix}golderrose${a} <text>
${a}├─ ❏ ${prefix}summernature${a} <text>
${a}├─ ❏ ${prefix}letterleaves${a} <text>
${a}├─ ❏ ${prefix}glowingneon${a} <text>
${a}├─ ❏ ${prefix}fallleaves${a} <text>
${a}├─ ❏ ${prefix}flamming${a} <text>
${a}├─ ❏ ${prefix}harrypotter${a} <text>
${a}├─ ❏ ${prefix}carvedwood${a} <text>
${a}├─ ❏ ${prefix}arcade8bit${a} <text>
${a}├─ ❏ ${prefix}battlefield4${a} <text>
${a}├─ ❏ ${prefix}pubg${a} <text>
${a}├─ ❏ ${prefix}bannerlol${a} <text>
${a}├─ ❏ ${prefix}wetglass${a} <text>
${a}├─ ❏ ${prefix}multicolor3d${a} <text>
${a}├─ ❏ ${prefix}watercolor${a} <text>
${a}├─ ❏ ${prefix}luxurygold${a} <text>
${a}├─ ❏ ${prefix}galaxywallpaper${a} <text>
${a}├─ ❏ ${prefix}lighttext${a} <text>
${a}├─ ❏ ${prefix}beautifulflower${a} <text>
${a}├─ ❏ ${prefix}puppycute${a} <text>
${a}├─ ❏ ${prefix}royaltext${a} <text>
${a}├─ ❏ ${prefix}heartshaped${a} <text>
${a}├─ ❏ ${prefix}birthdaycake${a} <text>
${a}├─ ❏ ${prefix}galaxystyle${a} <text>
${a}├─ ❏ ${prefix}hologram3d${a} <text>
${a}├─ ❏ ${prefix}greenneon${a} <text>
${a}├─ ❏ ${prefix}glossychrome${a} <text>
${a}├─ ❏ ${prefix}greenbush${a} <text>
${a}├─ ❏ ${prefix}metallogo${a} <text>
${a}├─ ❏ ${prefix}noeltext${a} <text>
${a}├─ ❏ ${prefix}glittergold${a} <text>
${a}├─ ❏ ${prefix}textcake${a} <text>
${a}├─ ❏ ${prefix}starsnight${a} <text>
${a}├─ ❏ ${prefix}wooden3d${a} <text>
${a}├─ ❏ ${prefix}textbyname${a} <text>
${a}├─ ❏ ${prefix}writegalacy${a} <text>
${a}├─ ❏ ${prefix}galaxybat${a} <text>
${a}├─ ❏ ${prefix}snow3d${a} <text>
${a}├─ ❏ ${prefix}birthdayday${a} <text>
${a}├─ ❏ ${prefix}goldplaybutton${a} <text>
${a}├─ ❏ ${prefix}silverplaybutton${a} <text>
${a}├─ ❏ ${prefix}freefire${a} <text>
${a}├─ ❏ ${prefix}cartoongravity${a} <text>
${a}├─ ❏ ${prefix}anonymhacker${a} <text>
${a}├─ ❏ ${prefix}juventusshirt${a} <text>
${a}├─ ❏ ${prefix}realvintage${a} <text>
${a}├─ ❏ ${prefix}codwarzone${a} <text>
${a}├─ ❏ ${prefix}valorantbanner${a} <text>
${a}├─ ❏ ${prefix}ytkomen${a} <text>
${a}├─ ❏ ${prefix}hartatahta${a} <text>
${a}├─ ❏ ${prefix}hartacustom${a} <text>
${a}├─ ❏ ${prefix}attp${a} <text>
${a}├─ ❏ ${prefix}ttp${a} <text>
${a}├─ ❏ ${prefix}ttp2${a} <text>
${a}├─ ❏ ${prefix}ttp3${a} <text>
${a}├─ ❏ ${prefix}ttp4${a} <text>
${a}├─ ❏ ${prefix}amongus${a} <text>
${a}├─ ❏ ${prefix}carbon${a} <text>
${a}├─ ❏ ${prefix}gtapassed${a} <text>
${a}├─ ❏ ${prefix}shadow${a} <text>
${a}├─ ❏ ${prefix}romantic${a} <text>
${a}├─ ❏ ${prefix}smoke${a} <text>
${a}├─ ❏ ${prefix}burnpaper${a} <text>
${a}├─ ❏ ${prefix}lovemessage${a} <text>
${a}├─ ❏ ${prefix}undergrass${a} <text>
${a}├─ ❏ ${prefix}doubleheart${a} <text>
${a}├─ ❏ ${prefix}coffecup${a} <text>
${a}├─ ❏ ${prefix}coffecup2${a} <text>
${a}├─ ❏ ${prefix}lovetext${a} <text>
${a}├─ ❏ ${prefix}butterfly${a} <text>
${a}├─ ❏ ${prefix}glitch${a} <text>
${a}└─ ❏ ${prefix}nulis${a} <text>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'stalkermenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ STALKER MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}ytstalk${a} <channel>
${a}├─ ❏ ${prefix}pptiktok${a} <usernsme>
${a}├─ ❏ ${prefix}igstalk${a} <username>
${a}├─ ❏ ${prefix}githubstalk${a} <username>
${a}├─ ❏ ${prefix}tiktokstalk${a} <username>
${a}├─ ❏ ${prefix}mlstalk${a} <id>|<server>
${a}└─ ❏ ${prefix}ffstalk${a} <id>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'imageeditmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ IMAGE EDIT MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}wanted${a} <reply photo> <text>
${a}├─ ❏ ${prefix}gtav${a} <reply photo>
${a}├─ ❏ ${prefix}facebookpage${a} <reply photo> <text>
${a}├─ ❏ ${prefix}costumwp${a} <reply photo>
${a}├─ ❏ ${prefix}komunis${a} <reply photo>
${a}├─ ❏ ${prefix}deletepc${a} <reply photo>
${a}├─ ❏ ${prefix}pantaimalam${a} <reply photo>
${a}├─ ❏ ${prefix}imgtourl${a} <reply photo>
${a}├─ ❏ ${prefix}pencil${a} <reply photo>
${a}├─ ❏ ${prefix}pencil2${a} <reply photo>
${a}├─ ❏ ${prefix}pencil3${a} <reply photo>
${a}├─ ❏ ${prefix}deepfry${a} <reply photo>
${a}├─ ❏ ${prefix}wasted${a} <reply photo>
${a}├─ ❏ ${prefix}fisheye${a} <reply photo>
${a}├─ ❏ ${prefix}flip${a} <reply photo>
${a}├─ ❏ ${prefix}roundimage${a} <reply photo>
${a}├─ ❏ ${prefix}deepfry${a} <reply photo>
${a}├─ ❏ ${prefix}trash${a} <reply photo>
${a}├─ ❏ ${prefix}facepalm${a} <reply photo>
${a}├─ ❏ ${prefix}affect${a} <reply photo>
${a}├─ ❏ ${prefix}tosmile${a} <reply photo>
${a}├─ ❏ ${prefix}skullmask${a} <reply photo>
${a}├─ ❏ ${prefix}alien${a} <reply photo>
${a}├─ ❏ ${prefix}triggered${a} <reply photo>
${a}├─ ❏ ${prefix}cartoon${a} <reply photo>
${a}├─ ❏ ${prefix}pixelate${a} <reply photo>
${a}├─ ❏ ${prefix}bakar${a} <reply photo>
${a}├─ ❏ ${prefix}crossgun${a} <reply photo>
${a}├─ ❏ ${prefix}picture${a} <reply photo>
${a}├─ ❏ ${prefix}hitler${a} <reply photo>
${a}├─ ❏ ${prefix}blur${a} <reply photo>
${a}├─ ❏ ${prefix}blur${a}beautiful${a} <reply photo>
${a}├─ ❏ ${prefix}blur${a}removebg${a} <reply photo>
${a}├─ ❏ ${prefix}blur${a}memegen${a} <reply photo> <text>|<text>
${a}└─ ❏ ${prefix}invert${a} <reply photo>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'sertifikatmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ SERTIFIKAT MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}tololserti${a} <text>
${a}├─ ❏ ${prefix}fuckboyserti${a} <text>
${a}├─ ❏ ${prefix}fuckgirlserti${a} <text>
${a}├─ ❏ ${prefix}bucinserti${a} <text>
${a}├─ ❏ ${prefix}pacarserti${a} <text>
${a}├─ ❏ ${prefix}goodboyserti${a} <text>
${a}├─ ❏ ${prefix}goodgirlserti${a} <text>
${a}├─ ❏ ${prefix}badboyserti${a} <text>
${a}├─ ❏ ${prefix}badgirlserti${a} <text>
${a}├─ ❏ ${prefix}hekelserti${a} <text>
${a}├─ ❏ ${prefix}fftourserti${a} <text>
${a}├─ ❏ ${prefix}fftourserti2${a} <text>
${a}├─ ❏ ${prefix}fftourserti3${a} <text>
${a}├─ ❏ ${prefix}fftourserti4${a} <text>
${a}├─ ❏ ${prefix}fftourserti5${a} <text>
${a}├─ ❏ ${prefix}mltourserti${a} <text>
${a}├─ ❏ ${prefix}mltourserti2${a} <text>
${a}├─ ❏ ${prefix}mltourserti3${a} <text>
${a}├─ ❏ ${prefix}mltourserti4${a} <text>
${a}├─ ❏ ${prefix}mltourserti5${a} <text>
${a}├─ ❏ ${prefix}pubgtourserti${a} <text>
${a}├─ ❏ ${prefix}pubgtourserti2${a} <text>
${a}├─ ❏ ${prefix}pubgtourserti3${a} <text>
${a}├─ ❏ ${prefix}pubgtourserti4${a} <text>
${a}└─ ❏ ${prefix}pubgtourserti5${a} <text>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'informationmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ INFORMATION MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}covidglobal${a}
${a}├─ ❏ ${prefix}coviddpuhyo${a}
${a}├─ ❏ ${prefix}jamdpuhyo${a}
${a}├─ ❏ ${prefix}jadwaltv${a} <channel>
${a}├─ ❏ ${prefix}infocuaca${a} <daerah>
${a}├─ ❏ ${prefix}infotsunami${a}
${a}└─ ❏ ${prefix}infogempa${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'othermenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ OTHER MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}sticker${a} <reply photo>
${a}├─ ❏ ${prefix}colong${a} <reply sticker>
${a}├─ ❏ ${prefix}takestick${a} <name>|<author>
${a}├─ ❏ ${prefix}stickerwm${a} <name>|<author>
${a}├─ ❏ ${prefix}ocr${a} <reply photo>
${a}├─ ❏ ${prefix}semoji${a} <emoji>
${a}├─ ❏ ${prefix}kontag${a} <nama>|<nomer>
${a}├─ ❏ ${prefix}spatrick${a}
${a}├─ ❏ ${prefix}viewsource${a} <website>
${a}├─ ❏ ${prefix}subdo${a} <website>
${a}├─ ❏ ${prefix}nmap${a} <website>
${a}├─ ❏ ${prefix}fak${a} <text>
${a}├─ ❏ ${prefix}hekweb${a} <text>
${a}├─ ❏ ${prefix}toimg${a} <reply sticker>
${a}├─ ❏ ${prefix}ssweb${a} <url>
${a}├─ ❏ ${prefix}sswebfull${a} <url>
${a}└─ ❏ ${prefix}telesticker${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'funmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ FUN MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}tts${a} <kode bahasa> <text>
${a}├─ ❏ ${prefix}tts2${a} <text>
${a}├─ ❏ ${prefix}slot${a}
${a}├─ ❏ ${prefix}dadu${a}
${a}├─ ❏ ${prefix}caklontong${a}
${a}├─ ❏ ${prefix}family100${a}
${a}├─ ❏ ${prefix}translate${a} <text>
${a}├─ ❏ ${prefix}tebakkata${a}
${a}├─ ❏ ${prefix}tebakgambar${a}
${a}├─ ❏ ${prefix}tebakgambar2${a}
${a}├─ ❏ ${prefix}tebakgambar3${a}
${a}├─ ❏ ${prefix}artinama${a} <text>
${a}├─ ❏ ${prefix}truth${a}
${a}├─ ❏ ${prefix}darel${a}
${a}├─ ❏ ${prefix}bisakah${a} <text>
${a}├─ ❏ ${prefix}kapankah${a} <text>
${a}├─ ❏ ${prefix}apakah${a} <text>
${a}├─ ❏ ${prefix}bagaimanakah${a} <text>
${a}├─ ❏ ${prefix}rate${a}
${a}├─ ❏ ${prefix}sangecek${a}
${a}├─ ❏ ${prefix}gaycek${a}
${a}├─ ❏ ${prefix}lesbicek${a}
${a}├─ ❏ ${prefix}gantengcek${a}
${a}├─ ❏ ${prefix}cantikcek${a}
${a}├─ ❏ ${prefix}watak${a}
${a}├─ ❏ ${prefix}hobby${a}
${a}├─ ❏ ${prefix}jadian${a}
${a}├─ ❏ ${prefix}ngewe${a}
${a}├─ ❏ ${prefix}terganteng${a}
${a}└─ ❏ ${prefix}tercantik${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'mediamenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ MEDIA MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}nickff${a}
${a}├─ ❏ ${prefix}ceritahoror${a}
${a}├─ ❏ ${prefix}quotes${a}
${a}├─ ❏ ${prefix}quotesdilan${a}
${a}├─ ❏ ${prefix}faktaunik${a}
${a}├─ ❏ ${prefix}katakatabijak${a}
${a}├─ ❏ ${prefix}randompantun${a}
${a}├─ ❏ ${prefix}randombucin${a}
${a}├─ ❏ ${prefix}katakatabucin${a}
${a}├─ ❏ ${prefix}memedpuhyo${a}
${a}├─ ❏ ${prefix}darkjoke${a}
${a}├─ ❏ ${prefix}estetik${a}
${a}├─ ❏ ${prefix}ppcouple${a}
${a}└─ ❏ ${prefix}randomnama${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'spammenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ SPAM MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}spamsms${a} <nomer>
${a}├─ ❏ ${prefix}spamgmail${a} <gmail>|<subjek>|<pesan>
${a}└─ ❏ ${prefix}spamcall${a} <nomer>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'filmmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ FILM MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}searchfilm${a} <text>
${a}├─ ❏ ${prefix}filmapikterbaru${a}
${a}├─ ❏ ${prefix}filmapikdrama${a}
${a}└─ ❏ ${prefix}lk21${a} <text>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'toolsmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ TOOLS MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}base64encode${a} <text>
${a}├─ ❏ ${prefix}base64decode${a} <text>
${a}├─ ❏ ${prefix}base32hexencode${a} <text>
${a}├─ ❏ ${prefix}base32hexdecode${a} <text>
${a}├─ ❏ ${prefix}binaryencode${a} <text>
${a}├─ ❏ ${prefix}binarydecode${a} <text>
${a}├─ ❏ ${prefix}octalencode${a} <text>
${a}├─ ❏ ${prefix}octaldecode${a} <text>
${a}├─ ❏ ${prefix}hexencode${a} <text>
${a}├─ ❏ ${prefix}hexdecode${a} <text>
${a}├─ ❏ ${prefix}shortlink${a} <url>
${a}├─ ❏ ${prefix}shortlink2${a} <url>
${a}└─ ❏ ${prefix}shortlink3${a} <url>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'animemenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ ANIME MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}dewabatch${a} <anime>
${a}├─ ❏ ${prefix}kusonime${a} <anime>
${a}├─ ❏ ${prefix}randomnekonime${a}
${a}├─ ❏ ${prefix}randomanime${a}
${a}├─ ❏ ${prefix}randomwaifu${a}
${a}├─ ❏ ${prefix}animesaran${a}
${a}├─ ❏ ${prefix}animesaran2${a}
${a}├─ ❏ ${prefix}storyanime${a}
${a}├─ ❏ ${prefix}wait${a} <reply photo>
${a}├─ ❏ ${prefix}fuutarou${a}
${a}├─ ❏ ${prefix}itsuki${a}
${a}├─ ❏ ${prefix}miku${a}
${a}├─ ❏ ${prefix}nino${a}
${a}├─ ❏ ${prefix}yotsuba${a}
${a}├─ ❏ ${prefix}ichika${a}
${a}├─ ❏ ${prefix}tanjiro${a}
${a}├─ ❏ ${prefix}nezuko${a}
${a}├─ ❏ ${prefix}zenitsu${a}
${a}├─ ❏ ${prefix}giyu${a}
${a}├─ ❏ ${prefix}sakonji${a}
${a}├─ ❏ ${prefix}inosuke${a}
${a}├─ ❏ ${prefix}shinobu${a}
${a}├─ ❏ ${prefix}kanao${a}
${a}├─ ❏ ${prefix}sayu${a}
${a}├─ ❏ ${prefix}yoshida${a}
${a}├─ ❏ ${prefix}airi${a}
${a}├─ ❏ ${prefix}asami${a}
${a}├─ ❏ ${prefix}hashimoto${a}
${a}├─ ❏ ${prefix}yuzuha${a}
${a}├─ ❏ ${prefix}eren${a}
${a}├─ ❏ ${prefix}mikasa${a}
${a}├─ ❏ ${prefix}armin${a}
${a}├─ ❏ ${prefix}levi${a}
${a}├─ ❏ ${prefix}bertholdt
${a}├─ ❏ ${prefix}erwin${a}
${a}├─ ❏ ${prefix}reiner${a}
${a}├─ ❏ ${prefix}annie${a}
${a}├─ ❏ ${prefix}hanji${a}
${a}├─ ❏ ${prefix}jean${a}
${a}├─ ❏ ${prefix}connie${a}
${a}├─ ❏ ${prefix}historia${a}
${a}├─ ❏ ${prefix}sasha${a}
${a}├─ ❏ ${prefix}grisha${a}
${a}├─ ❏ ${prefix}pixis${a}
${a}├─ ❏ ${prefix}frieda${a}
${a}├─ ❏ ${prefix}carla${a}
${a}├─ ❏ ${prefix}marco${a}
${a}├─ ❏ ${prefix}ymir${a}
${a}├─ ❏ ${prefix}floch${a}
${a}├─ ❏ ${prefix}anka${a}
${a}├─ ❏ ${prefix}eld${a}
${a}├─ ❏ ${prefix}rico${a}
${a}├─ ❏ ${prefix}petra${a}
${a}├─ ❏ ${prefix}ai${a}
${a}├─ ❏ ${prefix}momoe${a}
${a}├─ ❏ ${prefix}neirul${a}
${a}└─ ❏ ${prefix}rika${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'searchingmenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ SEARCHING MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}playstore${a} <aplikasi>
${a}├─ ❏ ${prefix}pinterest${a} <text>
${a}├─ ❏ ${prefix}pinterest2${a} <text>
${a}├─ ❏ ${prefix}pinterest3${a} <text>
${a}├─ ❏ ${prefix}pinterest4${a} <text>
${a}├─ ❏ ${prefix}image${a} <text>
${a}├─ ❏ ${prefix}gsmarena${a} <merek hp>
${a}├─ ❏ ${prefix}resepmakanan${a} <makanan>
${a}├─ ❏ ${prefix}wikipedia${a} <text>
${a}└─ ❏ ${prefix}brainly${a} <text>
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
                case 'beritamenu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                dapuhy = `
${a}◪ BERITA MENU${a}
${a}│${a}
${a}├─ ❏ ${prefix}sindo${a} (internasional)
${a}├─ ❏ ${prefix}sindo2${a} (nasional)
${a}├─ ❏ ${prefix}okezone${a}
${a}├─ ❏ ${prefix}kompastv${a}
${a}├─ ❏ ${prefix}bbcnews${a}
${a}└─ ❏ ${prefix}beritanews${a}
` 

                await dappauhuy(dapuhy, MessageType.text, tescuk, `「 ${namabot} 」\n Created By @${namaowner}`)
                break
//==========================================BATES NGAB==========================================\\
//MAKER MENU
                case 'blackpink':
                case 'neon':
                case 'greenneon':
                case 'advanceglow':
                case 'futureneon':
                case 'sandwriting':
                case 'sandsummer':
                case 'sandengraved':
                case 'metaldark':
                case 'neonlight':
                case 'holographic':
                case 'text1917':
                case 'minion':
                case 'deluxesilver':
                case 'newyearcard':
                case 'bloodfrosted':
                case 'halloween':
                case 'jokerlogo':
                case 'fireworksparkle':
                case 'natureleaves':
                case 'bokeh':
                case 'toxic':
                case 'strawberry':
                case 'box3d':
                case 'roadwarning':
                case 'breakwall':
                case 'icecold':
                case 'luxury':
                case 'cloud':
                case 'summersand':
                case 'horrorblood':
                case 'thunder':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                dppa = args.join(" ")
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/textprome/${command}?apikey=${LolHuman}&text=${dppa}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'pornhub':
                case 'avenger':
                case 'space':
                case 'ninjalogo':
                case 'marvelstudio':
                case 'lionlogo':
                case 'wolflogo':
                case 'steel3d':
                case 'wallgravity':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|ganz`)
                ct = args.join(" ")
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/textprome2/${command}?apikey=${LolHuman}&text1=${dap1}&text2=${dap2}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'cup':
                case 'cup1':
                case 'woodenboard':
                case 'coffe':
                case 'woodheart':
                case 'summer3d':
                case 'love':
                case 'wolfmetal':
                case 'nature3d':
                case 'underwater':
                case 'golderrose':
                case 'summernature':
                case 'letterleaves':
                case 'glowingneon':
                case 'fallleaves':
                case 'flamming':
                case 'harrypotter':
                case 'carvedwood':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                dppa = args.join(" ")
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/photooxy1/${command}?apikey=${LolHuman}&text=${dppa}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'tiktok':
                case 'arcade8bit':
                case 'battlefield4':
                case 'pubg':
                case 'bannerlol':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|ganz`)
                ct = args.join(" ")
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/photooxy2/${command}?apikey=${LolHuman}&text1=${dap1}&text2=${dap2}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'wetglass':
                case 'multicolor3d':
                case 'watercolor':
                case 'luxurygold':
                case 'galaxywallpaper':
                case 'lighttext':
                case 'beautifulflower':
                case 'puppycute':
                case 'royaltext':
                case 'heartshaped':
                case 'birthdaycake':
                case 'galaxystyle':
                case 'hologram3d':
                case 'greenneon':
                case 'glossychrome':
                case 'greenbush':
                case 'metallogo':
                case 'noeltext':
                case 'glittergold':
                case 'textcake':
                case 'starsnight':
                case 'wooden3d':
                case 'textbyname':
                case 'writegalacy':
                case 'galaxybat':
                case 'snow3d':
                case 'birthdayday':
                case 'goldplaybutton':
                case 'silverplaybutton':
                case 'freefire':
                case 'cartoongravity':
                case 'anonymhacker':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                dppa = args.join(" ")
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/ephoto1/${command}?apikey=${LolHuman}&text=${dppa}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'juventusshirt':
                case 'realvintage':
                case 'codwarzone':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|ganz`)
                ct = args.join(" ")
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/ephoto2/${command}?apikey=${LolHuman}&text1=${dap1}&text2=${dap2}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'juventusshirt':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|17`)
                ct = args.join(" ")
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/ephoto2/juventusshirt?apikey=${LolHuman}&text1=${dap1}&text2=${dap2}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'valorantbanner':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|mengkeren|cuy`)
                ct = args.join(" ")
                reply(dpuhy.wait())
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                dap3 = ct.split("|")[2];
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/ephoto3/valorantbanner?apikey=${LolHuman}&text1=${dap1}&text2=${dap2}&text3=${dap3}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'hartatahta':
                case 'hartacustom':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                dppa = args.join(" ")
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=${LolHuman}&text=${dppa}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'ytkomen':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|mengkeren|https://i.ibb.co/tpVB90V/20210411-171126.jpg`)
                ct = args.join(" ")
                reply(dpuhy.wait())
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                dap3 = ct.split("|")[2];
                dapuhy = await getBuffer(`http://lolhuman.herokuapp.com/api/ytcomment?apikey=${LolHuman}&username=${dap1}&comment=${dap2}&img=${dap3}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'attp':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                dppa = args.join(" ")
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.xteam.xyz/attp?file&text=${dppa}`)
                dp.sendMessage(from, dapuhy, sticker, {quoted: freply})
                await limitAdd(sender)
                break
                case 'ttp':
                case 'ttp2':
                case 'ttp3':
                case 'ttp4':
                case 'amongus':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                dppa = args.join(" ")
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=${LolHuman}&text=${dppa}`)
                dp.sendMessage(from, dapuhy, sticker, {quoted: freply})
                await limitAdd(sender)
                break
                case 'carbon':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                dppa = args.join(" ")
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/carbon?apikey=${LolHuman}&code=${dppa}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'gtapassed':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|respect`)
                ct = args.join(" ")
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                reply(dpuhy.wait())
                dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/gtapassed?apikey=${LolHuman}&text1=${dap1}&text2=${dap2}`)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'nulis':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                reply(dpuhy.wait())
                dppa = args.join(" ")
                anu = await fetchJson(`http://jamet1337.ml/api/nulis.php?tulis=${dppa}`)
                dapuhy = await getBuffer(anu.hasil)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'shadow':
                case 'romantic':
                case 'smoke':
                case 'burnpaper':
                case 'lovemessage':
                case 'undergrass':
                case 'doubleheart':
                case 'coffecup':
                case 'coffecup2':
                case 'lovetext':
                case 'butterfly':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}`)
                reply(dpuhy.wait())
                dppa = args.join(" ")
                anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/photooxy1/${command}?text=${dppa}&apikey=${DapApi}`)
                dapuhy = await getBuffer(anu.result.url)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'glitch':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`teksnya mana bruh?\ncontoh ${prefix + command} ${pushname}|ganz`)
                reply(dpuhy.wait())
                ct = args.join(" ")
                dap1 = ct.split("|")[0];
                dap2 = ct.split("|")[1];
                anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/photooxy2/glitch?text1=${dap1}&text2=${dap2}&apikey=${DapApi}`)
                dapuhy = await getBuffer(anu.result.url)
                dp.sendMessage(from, dapuhy, image, {quoted: freply})
                await limitAdd(sender)
                break
//==========================================BATES NGAB==========================================\\
//SEARCHING MENU
                case 'playstore':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh : ${prefix + command} telegram`)
                reply(dpuhy.wait())
                query = args.join(" ")
                get_result = await fetchJson(`http://api.lolhuman.xyz/api/playstore?apikey=${LolHuman}&query=${query}`)
                get_result = get_result.result
                ini_txt = 'Play Store Search : \n'
                for (var x of get_result) {
                ini_txt += `Name : ${x.title}\n`
                ini_txt += `ID : ${x.appId}\n`
                ini_txt += `Developer : ${x.developer}\n`
                ini_txt += `Link : ${x.url}\n`
                ini_txt += `Price : ${x.priceText}\n`
                ini_txt += `Price : ${x.price}`
                    }
                reply(ini_txt)
                await limitAdd(sender)
                break
				case 'wikipedia':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                suuu = body.slice(10)
				reply(dpuhy.wait())
				anu = await fetchJson(`http://api.lolhuman.xyz/api/wiki?apikey=${LolHuman}&query=${suuu}`)
				teks = `[ MENURUT WIKIPEDIA ] :\n\n${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'pinterest':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                carii = args.join(" ")
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.lolhuman.xyz/api/pinterest?apikey=${LolHuman}&query=${carii}`)
				toll = await getBuffer(anu.result)
				dp.sendMessage(from, toll, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pinterest2':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				cari = args.join(" ")
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.lolhuman.xyz/api/pinterest2?apikey=${LolHuman}&query=${cari}`)
				var dapp = JSON.parse(JSON.stringify(anu.result));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pinterest3':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				cari = args.join(" ")
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=${cari}`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pinterest4':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				cari = args.join(" ")
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?image=${cari}`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'resepmakanan':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                carii = args.join(" ")
				reply(dpuhy.wait())
				anu = await fetchJson(`http://zekais-api.herokuapp.com/resep?menu=${carii}`)
				teksnya = `Judul : ${anu.title}\n`
				teksnya += `Chef : ${anu.author}\n`
				teksnya += `Diterbitkan : ${anu.published}\n`
				teksnya += `Kesulitan : ${anu.dificulty}\n`
				teksnya += `Waktu : ${anu.times}\n`
				teksnya += `Porsi : ${anu.servings}\n\n\n`
				teksnya += `Bahan :\n${anu.ingredient}\n\n\n`
				teksnya += `Langkah :\n${anu.step}`
				toll = await getBuffer(anu.thumb)
				dp.sendMessage(from, toll, image, {quoted: freply, caption: teksnya})
				await limitAdd(sender)
				break
				case 'brainly':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                brien = body.slice(8)
			    brainly(`${brien}`).then(res => {
			    teks = '❉───────────❉\n'
				for (let Y of res.data) {
				teks += `\n「 _BRAINLY_ 」\n\n➸ Pertanyaan: ${Y.pertanyaan}\n\n➸ Jawaban: ${Y.jawaban[0].text}\n❉───────────❉\n`
				}
				dp.sendMessage(from, teks, text, {quoted: dap, detectLinks: false})
                console.log(res)
                })
				await limitAdd(sender)
				break
                case 'image':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`apa yang mau dicari ngab?\nContoh ${prefix}image nakano miku`)
                reply(dpuhy.wait())
                const gimg = args[0];
                gis(gimg, async (error, result) => {
                for (var i = 0; i < (result.length < 3 ? result.length : 3); i++) {
                var get = got(result[i].url);
           	    var stream = get.buffer();
                stream.then(async (images) => {
                await dp.sendMessage(from, images, image, {quoted: freply});
                });
          	    }
    		    });
        	    await limitAdd(sender)
        	    break
        	    case 'gsmarena':
        	    if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`apa yang mau dicari ngab?\nContoh ${prefix + command} iphone`)
                dpzz = args.join(" ")
                reply(dpuhy.wait())
        	    halah = await fetchJson(`https://leyscoders-api.herokuapp.com/api/gsm-arena?q=${dpzz}&apikey=${LeysApi}`)
        	    asu = halah.result
        	    img = await getBuffer(asu.thumb)
        	    hsil = `Nama : ${asu.spek}\n`
        	    hsil += `Type : ${asu.display_type}\n`
        	    hsil += `Size : ${asu.display_size}\n`
        	    hsil += `Resolusi : ${asu.display_resolusi}\n`
        	    hsil += `Chipset : ${asu.chipset}\n`
        	    hsil += `Os : ${asu.os}\n`
        	    hsil += `Cpu : ${asu.cpu}\n`
        	    hsil += `Internal : ${asu.internal}\n`
        	    hsil += `Camera : ${asu.camera}\n`
        	    hsil += `Batterai : ${asu.Batterai}`
        	    dp.sendMessage(from, img, image, {quoted: freply, caption: hsil})
        	    await limitAdd(sender)
        	    break
//==========================================BATES NGAB==========================================\\
//BERITA MENU
				case 'sindo':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/sindo/international?apikey=${LeysApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.data) {
				teks += `Judul : ${i.judul}\nWaktu : ${i.waktu}\nTipe : ${i.tipe}\nKutipan : ${i.kutipan}\nLink : ${i.link}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'sindo2':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/sindo/nasional?apikey=${LeysApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.data) {
				teks += `Judul : ${i.judul}\nWaktu : ${i.waktu}\nTipe : ${i.tipe}\nKutipan : ${i.kutipan}\nLink : ${i.link}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'okezone':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/okezone?apikey=${LeysApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result) {
				teks += `Judul : ${i.title}\nLink : ${i.url}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'kompastv':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/kompas?apikey=${LeysApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result) {
				teks += `Judul : ${i.title}\nGambar : ${i.img}\nWaktu : ${i.waktu}\nJenis : ${i.jenis}\nLink : ${i.url}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'bbcnews':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/bbc-news?apikey=${LeysApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result) {
				teks += `Judul : ${i.title}\nTerbit : ${i.terbit}\nWartawan : ${i.wartawan}\nGambar : ${i.img}\nDeskripsi : ${i.desc}\nLink : ${i.link}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'beritanews':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/berita-news?apikey=${LeysApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result) {
				teks += `Judul : ${i.title}\nGambar : ${i.img}\nLink : ${i.url}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
//==========================================BATES NGAB==========================================\\
//ISLAM MENU
                case 'tahlil':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/muslim/tahlil?apikey=${DapApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result.data) {
				teks += `Title : ${i.title}\nArab : ${i.arabic}\nTerjemah : ${i.translation}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
                case 'jadwalsholat':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh : ${prefix + command} Yogyakarta`)
                daerah = args.join(" ")
                get_result = await fetchJson(`http://api.lolhuman.xyz/api/sholat/${daerah}?apikey=${LolHuman}`)
                get_result = get_result.result
                ini_txt = `Wilayah : ${get_result.wilayah}\n`
                ini_txt += `Tanggal : ${get_result.tanggal}\n`
                ini_txt += `Sahur : ${get_result.sahur}\n`
                ini_txt += `Imsak : ${get_result.imsak}\n`
                ini_txt += `Subuh : ${get_result.subuh}\n`
                ini_txt += `Terbit : ${get_result.terbit}\n`
                ini_txt += `Dhuha : ${get_result.dhuha}\n`
                ini_txt += `Dzuhur : ${get_result.dzuhur}\n`
                ini_txt += `Ashar : ${get_result.ashar}\n`
                ini_txt += `Maghrib : ${get_result.maghrib}\n`
                ini_txt += `Isya : ${get_result.isya}`
                reply(ini_txt)
                await limitAdd(sender)
                break
                case 'kisahnabi':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/kisahnabi?nabi=${body.slice(11)}&apikey=${DapApi}`)
				buffer7 = await getBuffer(anu.result.nabi.image)
				teks = `HASIL\n\n➸ Nama Nabi : ${anu.result.nabi.nabi}\n➸ Lahir : ${anu.result.nabi.lahir}\n➸ Umur : ${anu.result.nabi.umur}\n➸ Tempat : ${anu.result.nabi.tempat}\n➸ Kisah : ${anu.result.nabi.kisah}`
				dp.sendMessage(from, buffer7, image, {quoted: dap, caption: teks})
				break
		        case 'ayatkursi':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/muslim/ayatkursi?apikey=${DapApi}`)
				teks = `➸ Arab : ${anu.result.data.arabic}\n➸ Latin : ${anu.result.data.latin}\n➸ Arti : ${anu.result.data.translation}\n➸ Tafsir : ${anu.result.data.tafsir}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
		        case 'doaharian':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				dp.updatePresence(from, Presence.composing) 
				reply(dpuhy.wait())
				asu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/muslim/doaharian?apikey=${DapApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of asu.result.data) {
					teks += `Nama Doa: : ${i.title}\nArab : ${i.arabic}\nLatin : ${i.latin}\nTranslation : ${i.translation}\n=================\n`
				}
				reply(teks)
				await limitAdd(sender)
				break
		        case 'niatsholat':  
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/muslim/niatshalat?apikey=${DapApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result) {
				teks += `Sholat : ${i.name}\nArab : ${i.arabic}\nLatin : ${i.latin}\nTerjemah : ${i.terjemahan}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
		        case 'bacaansholat':
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/muslim/bacaanshalat?apikey=${DapApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result) {
				teks += `Bacaan : ${i.name}\nArab : ${i.arabic}\nLatin : ${i.latin}\nTerjemah : ${i.terjemahan}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
//==========================================BATES NGAB==========================================\\
//SOUND MENU
case 'sound':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
dppa = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound.mp3`)
dp.sendMessage(from, dppa, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound1':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
satu = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound1.mp3`)
dp.sendMessage(from, satu, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound2':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
dua = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound2.mp3`)
dp.sendMessage(from, dua, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound3':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
tiga = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound3.mp3`)
dp.sendMessage(from, tiga, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound4':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
empat = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound4.mp3`)
dp.sendMessage(from, empat, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound5':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
lima = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound5.mp3`)
dp.sendMessage(from, lima, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound6':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
enam = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound6.mp3`)
dp.sendMessage(from, enam, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound7':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
tujuh = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound7.mp3`)
dp.sendMessage(from, tujuh, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound8':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
lapan = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound8.mp3`)
dp.sendMessage(from, lapan, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound9':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
bilan = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound9.mp3`)
dp.sendMessage(from, bilan, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
case 'sound10':
if (!isUser) return reply(dpuhy.noregis())
if (isBanned) return reply(dpuhy.wait())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
reply('[❗] Sabar Lagi Ngirim Audionya')
puluh = await getBuffer(`http://www.dapoa-web.xyz/untukbot/sound10.mp3`)
dp.sendMessage(from, puluh, audio, { mimetype: 'audio/mp4', filename: `${command}.mp3`, quoted: freply})
await limitAdd(sender)
break
//==========================================BATES NGAB==========================================\\
//ANIME MENU
                case 'dewabatch': 
                if (!isUser) return reply(dpuhy.noregis())
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                suuu = body.slice(11)
				reply(dpuhy.wait())
				anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/dewabatch?q=${suuu}`)
				foto = await getBuffer(anu.thumb)
				teks = `[ HASIL ]\n${anu.result}\n\n[ SINOPSIS ]\n${anu.sinopsis}`
				dp.sendMessage(from, foto, image, {quoted: freply, caption: teks})
				await limitAdd(sender)
				break
				case 'animesaran':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
		        dp.sendMessage(from, animesaran(), text, {quoted: fkontak})
		        await limitAdd(sender)
		        break
		        case 'animesaran2':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
		        dp.sendMessage(from, animesaran2(), text, {quoted: fkontak})
		        await limitAdd(sender)
		        break
				case 'kusonime': 
                if (!isUser) return reply(dpuhy.noregis())
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                suuu = body.slice(10)
				reply(dpuhy.wait())
				anu = await fetchJson(`https://docs-jojo.herokuapp.com/api/kuso?q=${suuu}`)
				foto = await getBuffer(anu.thumb)
				teks = `[ HASIL ]\nJudul ${anu.title}\n\n[ INFO ]\n${anu.info}\n\n[ LINK DOWNLOAD ]\n${anu.link_dl}\n\n[ SINOPSIS ]\n${anu.sinopsis}`
				dp.sendMessage(from, foto, image, {quoted: freply, caption: teks})
				await limitAdd(sender)
				break
				case 'storyanime':
                if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                reply(dpuhy.wait())
                dappa = await getBuffer(`https://ldpuhyow-api.herokuapp.com/api/randomaesthetic?apikey=LdpuhyowApi`)
                dp.sendMessage(from, dappa, video, {quoted: freply})
                await limitAdd(sender)
                break
                case 'wait':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.wait())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
				reply(dpuhy.wait())
				const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
				media = await dp.downloadMediaMessage(encmedia)
				await wait(media).then(res => {
				dp.sendMessage(from, res.video, video, {quoted: freply, caption: res.teks.trim()})
				}).catch(err => {
				reply(err)
				})
				} else {
				reply(dpuhy.ocron())
				}
				await limitAdd(sender)
			    break
			    case 'randomnekonime':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/nekonime?apikey=${LeysApi}`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'randomanime':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/random-nimek?apikey=${LeysApi}`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'randomwaifu':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/random-waifu?apikey=${LeysApi}`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'randomneko':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`http://zekais-api.herokuapp.com/randomneko`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fuutarou':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=fuutarou%20uesugi`, {method: 'get'})
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'itsuki':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=itsuki%20nakano`, {method: 'get'})
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'miku':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=miku%20nakano`, {method: 'get'})
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'nino':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=nino%20nakano`, {method: 'get'})
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'yotsuba':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=yotsuba%20nakano`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'ichika':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=ichika%20nakano`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'tanjiro':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=tanjiro%20kamado`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'nezuko':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=nezuko%20kamado`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'zenitsu':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=zenitsu%20agatsuma`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'giyu':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=giyu%20tomioka`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'sakonji':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=sakonji%20urokodaki`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'inosuke':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=inosuke%20hashibira`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'shinobu':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=shinobu%20kocho`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'kanao':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=kanao%20tsuyuri`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'sayu':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=sayu%20ogiwara`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'yoshida':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=yoshida`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'airi':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=airi%20gotou`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'asami':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=asami%20yuuki`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'hashimoto':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=hashimoto`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'yuzuha':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=yuzuha%20mishima`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'eren':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=eren%20yeager`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'mikasa':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=mikasa%20ackerman`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'armin':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=armin%20arlert`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'levi':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=levi%20ackerman`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'bertholdt':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=bertholdt%20hoover`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'erwin':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=erwin%20smith`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'reiner':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=reiner%20braun`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'annie':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=annie%20leonhart`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'hanji':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=hanji%20zoe`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'jean':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=jean%20kirstein`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'connie':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=connie%20springer`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'historia':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=historia%20reiss`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'sasha':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=sasha%20braus`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'grisha':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=grisha%20jaeger`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pixis':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=dot%20pixis`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'frieda':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=frieda%20reiss`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'carla':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=carla%20jaeger`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'marco':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=marco%20bodt`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'ymir':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=ymir%20attack%20on%20titan`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'floch':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=floch%20forster`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'anka':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=anka%20rheinberger`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'eld':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=eld%20gin`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'rico':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=rico%20brzenska`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'petra':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=petra%20ral`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'ai':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=ai%20ooto`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'momoe':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=momoe%20sawaki`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'neiru':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=neiru%20aonuma`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'rika':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=rika%20kawai`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'korosensei':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=koro%20sensei`)
				var dapp = JSON.parse(JSON.stringify(anu));
				var pa =  dapp[Math.floor(Math.random() * dapp.length)];
				uhy = await getBuffer(pa)
				dp.sendMessage(from, uhy, image, {quoted: freply})
				await limitAdd(sender)
				break
//==========================================BATES NGAB==========================================\\
//STALKER MENU
				case 'igstalk':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply('[❗] Sabar lagi stalking IG nya')
				get_result = await fetchJson(`http://lolhuman.herokuapp.com/api/stalkig/${body.slice(9)}?apikey=${LolHuman}`, {method: 'get'})
				get_result = get_result.result
				txt = `Link : https://www.instagram.com/${get_result.username}\n`
				txt += `Full : ${get_result.fullname}\n`
				txt += `Post : ${get_result.posts}\n`
				txt += `Followers : ${get_result.followers}\n`
				txt += `Following : ${get_result.following}\n`
				txt += `Bio : ${get_result.bio}\n`
				buffer = await getBuffer(get_result.photo_profile)
				dp.sendMessage(from, buffer, image, {quoted: freply, caption: txt})
				await limitAdd(sender)
				break
				case 'pptiktok':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				dptod = args.join(" ")
				kntl = await getBuffer(`https://api.lolhuman.xyz/api/pptiktok/${dptod}?apikey=${LolHuman}`)
				dp.sendMessage(from, kntl, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'githubstalk':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply('[❗] Sabar lagi stalking GitHub nya')
				get_result = await fetchJson(`http://lolhuman.herokuapp.com/api/github/${body.slice(13)}?apikey=${LolHuman}`, {method: 'get'})
				get_result = get_result.result
				txt = `Full : ${get_result.name}\n`
				txt += `Followers : ${get_result.followers}\n`
				txt += `Following : ${get_result.following}\n`
				txt += `Publick : ${get_result.public_repos}\n`
				txt += `Public Gits : ${get_result.public_gists}\n`
				txt += `User : ${get_result.user}\n`
				txt += `Compi : ${get_result.company}\n`
				txt += `Lokasi : ${get_result.location}\n`
				txt += `Email : ${get_result.email}\n`
				txt += `Bio : ${get_result.bio}\n`
				buffer = await getBuffer(get_result.avatar)
				dp.sendMessage(from, buffer, image, {quoted: freply, caption: txt})
				await limitAdd(sender)
				break
				case 'tiktokstalk':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply('[❗] Sabar lagi stalking TikTok nya')
				username = args[0]
				get_result = await fetchJson(`http://lolhuman.herokuapp.com/api/stalktiktok/${username}?apikey=${LolHuman}`, {method: 'get'})
				get_result = get_result.result
				txt = `Link : ${get_result.username}\n`
				txt += `Bio : ${get_result.bio}\n`
				txt += `Followers : ${get_result.followers}\n`
				txt += `Following : ${get_result.followings}\n`
				txt += `Likes : ${get_result.likes}\n`
				txt += `Vidio : ${get_result.video}\n`
				buffer = await getBuffer(get_result.user_picture)
				dp.sendMessage(from, buffer, image, {quoted: freply, caption: txt})
				await limitAdd(sender)
				break
				case 'ytstalk':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply('[❗] Sabar lagi stalking YT nya')
				ytk = args.join(" ")
				anu = await fetchJson(`http://api.lolhuman.xyz/api/ytchannel?apikey=${LolHuman}&query=${ytk}`, {method: 'get'})
				cari = '•••••••••••••••••\n'
				for (let search of anu.result) {
				cari += `Chanel : ${search.channel_name}\nTentang : ${search.channel_about}\nCreated : ${search.channel_created}\nLink : https://youtu.com/channel/${search.channel_id}\n•••••••••••••••••\n`
				}
				reply(cari.trim())
				await limitAdd(sender)
				break
				case 'mlstalk':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply('[❗] Sabar lagi stalking Mobile Legend nya')
				ha = args.join(" ")
				id = ha.split("|")[0];
                server = ha.split("|")[1];
				get_result = await fetchJson(`https://api.lolhuman.xyz/api/mobilelegend/${id}/${server}?apikey=${LolHuman}`, {method: 'get'})
				txt = `Nickname : ${get_result.result}`
				dp.sendMessage(from, txt, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'ffstalk':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply('[❗] Sabar lagi stalking Free Fire nya')
				id = args.join(" ")
				ngntl = await fetchJson(`https://api.lolhuman.xyz/api/freefire/${id}?apikey=${LolHuman}`, {method: 'get'})
				hsil = `Nickname : ${ngntl.result}`
				dp.sendMessage(from, hsil, text, {quoted: fkontak})
				await limitAdd(sender)
				break
//==========================================BATES NGAB==========================================\\
//DOWNLOAD MENU
				case 'ytplay':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh : ${prefix + command} Melukis Senja`)
                reply(dpuhy.wait())
                query = args.join(" ")
                get_result = await fetchJson(`http://api.lolhuman.xyz/api/ytplay?apikey=${LolHuman}&query=${query}`)
                get_result = get_result.result
                get_info = get_result.info
                ini_txt = `Title : ${get_info.title}\n`
                ini_txt += `Uploader : ${get_info.uploader}\n`
                ini_txt += `Duration : ${get_info.duration}\n`
                ini_txt += `View : ${get_info.view}\n`
                ini_txt += `Like : ${get_info.like}\n`
                ini_txt += `Dislike : ${get_info.dislike}\n`
                ini_txt += `Description :\n ${get_info.description}\n\n\n`
                ini_buffer = await getBuffer(get_info.thumbnail)
                dp.sendMessage(from, ini_buffer, image, { quoted: freply, caption: ini_txt })
                get_audio = await getBuffer(get_result.audio[3].link)
                dp.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${get_info.title}.mp3`, quoed: freply})
                get_video = await getBuffer(get_result.video[0].link)
                dp.sendMessage(from, get_video, video, { mimetype: 'video/mp4', filename: `${get_info.title}.mp4`, quoed: freply})
                await limitAdd(sender)
                break
                case 'tiktoknowm':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (args.length < 1) return reply(`Linknya Mana Cuy?\nContoh : ${prefix + command} https://vm.tiktok.com/ZSJkHUCwK/`)
                reply(dpuhy.wait())
                link = args.join(" ")
                dppa = await fetchJson(`http://zekais-api.herokuapp.com/tiktok2?url=${link}`)
                buffer = await getBuffer(dap.result)
                dp.sendMessage(from, buffer, MessageType.video, {quoted: freply})
                await limitAdd(sender)
                break
                case 'igvideo':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (args.length < 1) return reply(`Linknya Mana Cuy?\nContoh : ${prefix + command} https://www.instagram.com/p/CNzcf8egt27/?igshid=1hbl53id19nqv`)
                reply(dpuhy.wait())
                link = args[0]
                resultnya = await fetchJson(`https://leyscoders-api.herokuapp.com/api/instagram/video?url=${link}&apikey=${LeysApi}`)
                buffer = await getBuffer(resultnya.result)
                dp.sendMessage(from, buffer, MessageType.video, {quoted: freply})
                await limitAdd(sender)
                break
                case 'igphoto':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (args.length < 1) return reply(`Linknya Mana Cuy?\nContoh : ${prefix + command} https://www.instagram.com/p/CNzQL4cHm4n/?igshid=19n977531z5nz`)
                reply(dpuhy.wait())
                link = args[0]
                resultnya = await fetchJson(`https://leyscoders-api.herokuapp.com/api/instagram/photo?url=${link}&apikey=${LeysApi}`)
                buffer = await getBuffer(resultnya.result)
                dp.sendMessage(from, buffer, MessageType.image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'ytmp3':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (args.length < 1) return reply(`linknya mana cuy?\nContoh : ${prefix + command} https://youtu.be/b0md2fEIFpg`)
                reply(dpuhy.wait())
                ini_link = args[0]
                get_result = await fetchJson(`http://api.lolhuman.xyz/api/ytaudio?apikey=${LolHuman}&url=${ini_link}`)
                get_result = get_result.result
                ini_txt = `Title : ${get_result.title}\n`
                ini_txt += `Uploader : ${get_result.uploader}\n`
                ini_txt += `Duration : ${get_result.duration}\n`
                ini_txt += `View : ${get_result.view}\n`
                ini_txt += `Like : ${get_result.like}\n`
                ini_txt += `Dislike : ${get_result.dislike}\n`
                ini_txt += `Description :\n ${get_result.description}\n\n\n`
                ini_buffer = await getBuffer(get_result.thumbnail)
                dp.sendMessage(from, ini_buffer, image, { quoted: freply, caption: ini_txt })
                get_audio = await getBuffer(get_result.link[3].link)
                dp.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${get_result.title}.mp3`, quoed: freply})
                await limitAdd(sender)
                break
                case 'ytmp4':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (args.length < 1) return reply(`Linknya Mana Cuy?\nContoh : ${prefix + command} https://youtu.be/b0md2fEIFpg`)
                reply(dpuhy.wait())
                ini_link = args[0]
                get_result = await fetchJson(`http://api.lolhuman.xyz/api/ytvideo?apikey=${LolHuman}&url=${ini_link}`)
                get_result = get_result.result
                ini_txt = `Title : ${get_result.title}\n`
                ini_txt += `Uploader : ${get_result.uploader}\n`
                ini_txt += `Duration : ${get_result.duration}\n`
                ini_txt += `View : ${get_result.view}\n`
                ini_txt += `Like : ${get_result.like}\n`
                ini_txt += `Dislike : ${get_result.dislike}\n`
                ini_txt += `Description :\n ${get_result.description}\n\n\n`
                ini_buffer = await getBuffer(get_result.thumbnail)
                dp.sendMessage(from, ini_buffer, image, { quoted: freply, caption: ini_txt })
                get_audio = await getBuffer(get_result.link[0].link)
                dp.sendMessage(from, get_audio, video, { mimetype: 'video/mp4', filename: `${get_result.title}.mp4`, quoed: freply})
                await limitAdd(sender)
                break
//==========================================BATES NGAB==========================================\\
//NSFW MENU
/*
MASI DIKUNCI BRO KALO MAU NYALAIN NYALAIN AJA
TAPI KALO DOSA TANGGUNG SENDIRI YA
                case 'nsfwneko':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/nsfwneko?apikey=GFL`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'nsfwpussy':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/pussy?apikey=GFL`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'nsfwahegao':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/ahegao?apikey=GFL`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'nsfwass':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/ass?apikey=GFL`)
				dapuhy = await getBuffer(anu.result)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'nsfwbdsm':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/bdsm?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
				case 'nsfwblowjob':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/blowjob?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
				case 'nsfwboobjob':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/boobjob?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
				case 'nsfwcreampie':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/creampie?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
				case 'nsfwcuckold':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/cuckold?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
				case 'nsfwglasses':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/glasses?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'nsfwcum':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/cum?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'nsfwfemdom':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/femdom?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
                case 'nsfwelves':
				if (!isNsfw) return reply(dpuhy.nsfwoff())
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
                anu = await fetchJson(`https://iwi-negev.herokuapp.com/api/nsfw/elves?apikey=GFL`)
                buffer = await getBuffer(anu.result)
                dp.sendMessage(from, buffer, image, {quoted: freply})
                await limitAdd(sender)
                break
*/
//==========================================BATES NGAB==========================================\\
//MATEMATIKA MENU
                case 'perkalian':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.wait())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Ngab?\nContoh ${prefix}perkalian 5/8`)
				reply(dpuhy.wait()) 
			    var gh = body.slice(10)
			    var angka1 = gh.split("*")[0];
			    var angka2 = gh.split("*")[1];
			    kali = await fetchJson(`https://leyscoders-api.herokuapp.com/api/perkalian?angka1=${angka1}&angka2=${angka2}&apikey=${LeysApi}`) 
			    hasil = `「 PERKALIAN 」\n\nHasil dari perkalian ${angka1}x${angka2} :\n${kali.result}`
                dp.sendMessage(from, hasil, text, {quoted: fkontak}) 
                await limitAdd(sender)
                break
			    case 'rumuspersegipanjang':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.wait())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Ngab?\nContoh ${prefix}rumuspersegipanjang 7/5`)
				reply(dpuhy.wait()) 
			    var gh = body.slice(20)
			    var panjang = gh.split("|")[0];
			    var lebar = gh.split("|")[1];
			    mtk = await fetchJson(`https://leyscoders-api.herokuapp.com/api/ppanjang?pjg=${panjang}&lebar=${lebar}&apikey=${LeysApi}`) 
			    dapp = `「 RUMUS PERSEGI PANJANG 」\n\nRumus keliling :\n${mtk.rumus_keliling}\n\nHasil keliling : ${mtk.hasil_keliling}\n↕↕↕↕↕↕\nRumus luas :\n${mtk.rumus_luas}\n\nHasil luas : ${mtk.hasil_luas}`
                dp.sendMessage(from, dapp, text, {quoted: fkontak}) 
                await limitAdd(sender)
                break
                case 'rumuspersegi':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.wait())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Ngab?\nContoh ${prefix}rumuspersegi 4`)
				reply(dpuhy.wait()) 
			    mtk = await fetchJson(`https://leyscoders-api.herokuapp.com/api/persegi?sisi=${body.slice(13)}&apikey=${LeysApi}`) 
			    dapp = `「 RUMUS PERSEGI 」\n\nRumus keliling :\n${mtk.rumus_keliling}\n\nHasil keliling : ${mtk.hasil_keliling}\n↕↕↕↕↕↕\nRumus luas :\n${mtk.rumus_luas}\n\nHasil luas : ${mtk.hasil_luas}`
                dp.sendMessage(from, dapp, text, {quoted: fkontak})
                await limitAdd(sender)
                break
                case 'kuadrat':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.wait())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Ngab?\nContoh ${prefix}kuadrat 8`)
				reply(dpuhy.wait()) 
			    mtk = await fetchJson(`https://leyscoders-api.herokuapp.com/api/bdr/kuadrat?q=${body.slice(9)}&apikey=${LeysApi}`) 
			    dapp = `「 KUADRAT 」\n\nKuadrat dari ${body.slice(8)} adalah : ${mtk.result}`
                dp.sendMessage(from, dapp, text, {quoted: fkontak}) 
                await limitAdd(sender)
                break
//==========================================BATES NGAB==========================================\\
//IMAGE EDIT MENU
case 'wanted':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
tels = body.slice(8)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/wanted/?urlgbr=${anu.display_url}&text1=DEATH or ALIVE&text2=${tels}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'gtav':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/gtavposter/?urlgbr=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'rotate':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`http://zekais-api.herokuapp.com/rotate?url=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'komunis':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`http://zekais-api.herokuapp.com/comunism?url=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'deletepc':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`http://zekais-api.herokuapp.com/delete?url=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'facebookpage':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
tels = body.slice(14)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/facebookprof/?urlgbr=${anu.display_url}&text=${tels}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'costumwp':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/customwp/?urlgbr=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'pantaimalam':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/nightbeach/?urlgbr=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'pencil3':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/pencil/?urlgbr=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'pencil2':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
woy = await getBuffer(`https://videfikri.com/api/textmaker/pencildrawing/?urlgbr=${anu.display_url}`)
dp.sendMessage(from, woy, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'bakar':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/burneffect/?urlgbr=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'crossgun':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://videfikri.com/api/textmaker/crossgun/?urlgbr=${anu.display_url}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'picture':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://leyscoders-api.herokuapp.com/api/img/picture?url=${anu.display_url}&apikey=${LeysApi}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'hitler':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://leyscoders-api.herokuapp.com/api/img/hitler?url=${anu.display_url}&apikey=${LeysApi}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'blur':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://leyscoders-api.herokuapp.com/api/img/blur?url=${anu.display_url}&apikey=${LeysApi}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'invert':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
anu = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
hehe = await getBuffer(`https://leyscoders-api.herokuapp.com/api/img/invert?url=${anu.display_url}&apikey=${LeysApi}`)
dp.sendMessage(from, hehe, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'imgtourl':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
reply(dpuhy.wait())
var encmedia  = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
var jnckk = await  dp.downloadAndSaveMediaMessage(encmedia)
var imgbb = require('imgbb-uploader')
imgbb('3b8594f4cb11895f4084291bc655e510', jnckk)
.then(data => {
var caps = `╭─「 IMGBB TO URL 」\n│\n│• ID : ${data.id}\n│• MimeType : ${data.image.mime}\n│• Extension : ${data.image.extension}\n│\n│• URL : ${data.display_url}\n╰─────────────────────`
ibb = fs.readFileSync(jnckk)
dp.sendMessage(from, ibb, image, { quoted: freply, caption: caps })
})
.catch(err => {
throw err 
})
await limitAdd(sender) 	
break
case 'beautiful':
case 'facepalm':
case 'affect':
case 'trash':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
dppa = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
uhyy = await getBuffer(`https://api.lolhuman.xyz/api/creator1/${command}?apikey=${LolHuman}&img=${dppa.display_url}`)
dp.sendMessage(from, uhyy, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'tosmile':
case 'skullmask':
case 'alien':
case 'cartoon':
case 'pixelate':
case 'pencil':
case 'wasted':
case 'fisheye':
case 'flip':
case 'roundimage':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
dppa = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
uhyy = await getBuffer(`https://api.lolhuman.xyz/api/editor/${command}?apikey=${LolHuman}&img=${dppa.display_url}`)
dp.sendMessage(from, uhyy, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'deepfry':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
dppa = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
uhyy = await getBuffer(`https://api.lolhuman.xyz/api/deepfry?apikey=${LolHuman}&img=${dppa.display_url}`)
dp.sendMessage(from, uhyy, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'removebg':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo: dap
reply(dpuhy.wait())
owgi = await dp.downloadAndSaveMediaMessage(ted)
dppa = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
uhyy = await getBuffer(`https://api.lolhuman.xyz/api/removebg?apikey=${LolHuman}&img=${dppa.display_url}`)
dp.sendMessage(from, uhyy, image, {quoted: freply})
} else {
reply('Reply Imagenya!!')
}
await limitAdd(sender)
break
case 'memegen':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
if ((isMedia && !dap.videoMessage || isQuotedImage)) {
var tex1 = body.slice(9).split('|')[0]
var tex2 = body.slice(9).split('|')[1]
if (!tex2) return reply('Format salah!')
var imgbb = require('imgbb-uploader')
reply(dpuhy.wait())
var ted = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace("quotedM", "m")).message.extendedTextMessage.contextInfo : dap
var owgi = await dp.downloadAndSaveMediaMessage(ted)
dppa = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
uhyy = await getBuffer(`https://lolhuman.herokuapp.com/api/memegen?apikey=${LolHuman}&texttop=${tex1}&textbottom=${tex2}&img=${dppa.display_url}`)
dp.sendMessage(from, uhyy, image, {quoted: freply})
}
await limitAdd(sender)
break
case 'triggered':
case 'trigger':
if (!isUser) return reply(dpuhy.noregis())
if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
if (isBanned) return reply(dpuhy.baned())
await limitAdd(sender)
var imgbb = require('imgbb-uploader')
if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
owgi = await dp.downloadAndSaveMediaMessage(ger)
dppa = await imgbb("3ea1465ef91578a90ee81f7d41c59a1f", owgi)
ranp = getRandom('.gif')
rano = getRandom('.webp')
uhyy = `https://some-random-api.ml/canvas/triggered?avatar=${dppa.display_url}`
exec(`wget ${uhyy} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return reply()
jadinyaa = fs.readFileSync(rano)
dp.sendMessage(from, kntlll, jadinyaa, {quoted: freply})
fs.unlinkSync(rano)
})                  
} else {
reply('Reply Imagenya!!')
}
break
//==========================================BATES NGAB==========================================\\
//FILM MENU
                case 'searchfilm':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
				film = await fetchJson(`http://zekais-api.herokuapp.com/film?query=${body.slice(12)}`, {method: 'get'})
				reply(dpuhy.wait())
				teks = '=================\n'
				for (let i of film.result) {
					teks += `Nama film : ${i.name}\nQuality : ${i.quality}\nLink : ${i.url}\n=================\n`
					}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'filmapikterbaru':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
				film = await fetchJson(`http://zekais-api.herokuapp.com/filmapiklatest`, {method: 'get'})
				reply(dpuhy.wait())
				teks = '=================\n'
				for (let i of film.result) {
					teks += `Nama film : ${i.name}\nQuality : ${i.quality}\nRating : ${i.rating}\nLink : ${i.url}\n=================\n`
					}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'filmapikdrama':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
				film = await fetchJson(`http://zekais-api.herokuapp.com/filmapiklatest`, {method: 'get'})
				reply(dpuhy.wait())
				teks = '=================\n'
				for (let i of film.result) {
					teks += `Nama film : ${i.name}\nQuality : ${i.quality}\nRating : ${i.rating}\nLink : ${i.url}\n=================\n`
					}
				reply(teks.trim())
				await limitAdd(sender)
				break
				case 'lk21':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh : ${prefix + command} Transformer`)
                query = args.join(" ")
                reply(dpuhy.wait())
                get_result = await fetchJson(`http://api.lolhuman.xyz/api/lk21?apikey=${LolHuman}&query=${query}`)
                get_result = get_result.result
                ini_txt = `Title : ${get_result.title}\n`
                ini_txt += `Link : ${get_result.link}\n`
                ini_txt += `Genre : ${get_result.genre}\n`
                ini_txt += `Views : ${get_result.views}\n`
                ini_txt += `Duration : ${get_result.duration}\n`
                ini_txt += `Tahun : ${get_result.tahun}\n`
                ini_txt += `Rating : ${get_result.rating}\n`
                ini_txt += `Desc : ${get_result.desc}\n`
                ini_txt += `Actors : ${get_result.actors.join(", ")}\n`
                ini_txt += `Location : ${get_result.location}\n`
                ini_txt += `Date Release : ${get_result.date_release}\n`
                ini_txt += `Language : ${get_result.language}\n`
                ini_txt += `Link Download : ${get_result.link_dl}`
                thumbnail = await getBuffer(get_result.thumbnail)
                dp.sendMessage(from, thumbnail, image, { quoted: freply, caption: ini_txt })
                await limitAdd(sender)
                break
//==========================================BATES NGAB==========================================\\
//INFORMATION MENU
                case 'covidglobal':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/covidworld?apikey=${DapApi}`)
				teks = `Total Cases : ${anu.result.totalCases}\nRecovered : ${anu.result.recovered}\nDeaths : ${anu.result.deaths}\nActive Cases : ${anu.result.activeCases}\nClosed Cases : ${anu.result.closedCases}\nLast Update : ${anu.result.lastUpdate}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'coviddpuhyo':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				dp.updatePresence(from, Presence.composing) 
				reply(dpuhy.wait())
				asu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/coviddpuhyo?apikey=${DapApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of asu.result) {
				teks += `Kode Provinsi: : ${i.attributes.Kode_Provi}\nProvinsi : ${i.attributes.Provinsi}\nTotal Positif : ${i.attributes.Kasus_Posi}\nTotal Sembuh : ${i.attributes.Kasus_Semb}\nTotal Meninggal : ${i.attributes.Kasus_Meni}\n=================\n`
				}
				reply(teks)
				await limitAdd(sender)
				break
				case 'jamdpuhyo':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				jam = `JAM dpuhyO ⏰\n\n\nWIB : ${time}\nWIT : ${wit}\nWITA : ${wita}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'jadwaltv':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Channelnya mana?`)
				reply(dpuhy.wait()) 
                chnl = args[0]
                suu = await fetchJson(`http://api.lolhuman.xyz/api/jadwaltv/${chnl}?apikey=${LolHuman}`)
                cok = suu.result
                txt = `Jadwal TV ${chnl.toUpperCase()}\n`
                for (var nj in cok) {
                txt += `${nj} - ${cok[nj]}\n`
                }
                reply(txt)
                await limitAdd(sender)
                break
                case 'infogempa':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
				reply(dpuhy.wait())
                get_result = await fetchJson(`http://api.lolhuman.xyz/api/infogempa?apikey=${LolHuman}`)
                get_result = get_result.result
                ini_txt = `Lokasi : ${get_result.lokasi}\n`
                ini_txt += `Waktu : ${get_result.waktu}\n`
                ini_txt += `Potensi : ${get_result.potensi}\n`
                ini_txt += `Magnitude : ${get_result.magnitude}\n`
                ini_txt += `Kedalaman : ${get_result.kedalaman}\n`
                ini_txt += `Koordinat : ${get_result.koordinat}`
                get_buffer = await getBuffer(get_result.map)
                dp.sendMessage(from, get_buffer, image, { quoted: freply, caption: ini_txt })
                await limitAdd(sender)
                break
                case 'infocuaca':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
				daerah = args[0]
				reply(dpuhy.wait())
                resultnya = await fetchJson(`http://leyscoders-api.herokuapp.com/api/cuaca?q=${daerah}&apikey=${LeysApi}`)
                dapgz = resultnya.result
                textnya = `Daerah : ${dapgz.Daerah}\n`
                textnya += `Latitude : ${dapgz.Latitude}\n`
                textnya += `Longitude : ${dapgz.Longitude}\n`
                textnya += `TimeZone : ${dapgz.TimeZone}\n`
                textnya += `Tanggal : ${dapgz.Tanggal}\n`
                textnya += `Waktu : ${dapgz.Waktu}\n`
                textnya += `Hari : ${dapgz.Hari}\n`
                textnya += `Cuaca : ${dapgz.Cuaca}`
                dp.sendMessage(from, textnya, text, {quoted: fkontak})
                await limitAdd(sender)
                break
                case 'infotsunami':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
				reply(dpuhy.wait())
                anuu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/info-tsunami?apikey=${LeysApi}`)
                dapxzuhy = anuu.result
                textcuk = `Waktu : ${dapxzuhy.waktu}\n`
                textcuk += `Magnitude : ${dapxzuhy.magnitude}\n`
                textcuk += `Kedalaman : ${dapxzuhy.Kedalaman}\n`
                textcuk += `Wilayah : ${dapxzuhy.Wilayah}\n`
                textcuk += `Koordinat : ${dapxzuhy.koordinat}\n`
                dp.sendMessage(from, textcuk, text, {quoted: fkontak})
                await limitAdd(sender)
                break
//==========================================BATES NGAB==========================================\\
//FUN MENU
			    case 'tts':
                if (!isUser) return reply(dpuhy.noregis())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (isBanned) return reply(dpuhy.baned())
				if (args.length < 1) return dp.sendMessage(from, `Diperlukan kode bahasa!!, ketik ${prefix}bahasa`, text, {quoted: freply})
				const gtts = require('./lib/gtts')(args[0])
				if (args.length < 2) return dp.sendMessage(from, 'Mana teks yang ma di jadiin suara? suara setan kah?', text, {quoted: freply})
				dtt = body.slice(8)
				reply(dpuhy.wait())
				ranm = getRandom('.mp3')
				rano = getRandom('.ogg')
				dtt.length > 300
				? reply('Textnya Kepanjangan Asu!!')
				: gtts.save(ranm, dtt, function() {
				exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
				fs.unlinkSync(ranm)
				buffer = fs.readFileSync(rano)
				if (err) return reply(dpuhy.stikga())
				dp.sendMessage(from, buffer, audio, {quoted: freply, ptt:true})
				fs.unlinkSync(rano)
				})
				})
				await limitAdd(sender)
				break
				case 'tts2':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                ct = body.slice(5)
                reply(dpuhy.wait())
                asu = await getBuffer(`http://zekais-api.herokuapp.com/speech?lang=id&text=${ct}`)
                dp.sendMessage(from, asu, audio, {mimetype: 'audio/mp4', quoed: freply})
                await limitAdd(sender)
                break
                case 'dadu':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
                asu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/dadu?apikey=${LeysApi}`)
                dadu = await getBuffer(asu.result)
                dp.sendMessage(from, dadu, image, {quoted: freply, caption: `Jika anda mendapatkan dadu 6 berati anda menang`})
                await limitAdd(sender)
                break
                case 'translate':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                ct = body.slice(11)
                reply(dpuhy.wait())
                asu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/translate?kata=${ct}&apikey=${DapApi}`)
                dapp = `English : ${ct}\nIndonesia : ${asu.result.text}`
                dp.sendMessage(from, dapp, text, {quoted: fkontak})
                await limitAdd(sender)
                break
                case 'caklontong':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/kuis/caklontong?apikey=${DapApi}`, {method: 'get'})
				caklontong = `${anu.result.soal}`
				setTimeout( () => {
				dp.sendMessage(from, '➸ Jawaban : '+anu.result.jawaban+ '\n\n• Penjelasan: '+ anu.result.deskripsi+'', text, {quoted: fkontak})
				}, 30000)
				setTimeout( () => {
				dp.sendMessage(from, '_10 Detik lagi…_', text, {quoted: fkontak})
				}, 20000)
				setTimeout( () => {
				dp.sendMessage(from, '_20 Detik lagi_…', text, {quoted: fkontak})
				}, 10000)
				setTimeout( () => {
				dp.sendMessage(from, '_30 Detik lagi_…', text, {quoted: fkontak})
				}, 2500)
				setTimeout( () => {
				dp.sendMessage(from, caklontong, text, {quoted: fkontak})
				}, 0)
				await limitAdd(sender) 
				break 
			    case 'family100':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
				anu = await fetchJson(`http://api.lolhuman.xyz/api/tebak/family100?apikey=${LolHuman}`, {method: 'get'})
				family = `${anu.result.question}`
				setTimeout( () => {
				dp.sendMessage(from, '➸ Jawaban : '+anu.result.aswer, text, {quoted: fkontak})
				}, 30000)
				setTimeout( () => {
				dp.sendMessage(from, '_10 Detik lagi…_', text, {quoted: fkontak})
				}, 20000)
				setTimeout( () => {
				dp.sendMessage(from, '_20 Detik lagi_…', text, {quoted: fkontak})
				}, 10000)
				setTimeout( () => {
				dp.sendMessage(from, '_30 Detik lagi_…', text, {quoted: fkontak})
				}, 2500)
				setTimeout( () => {
				dp.sendMessage(from, family, text, {quoted: fkontak})
				}, 0)
				await limitAdd(sender) 
				break 
			    case 'slot':
			    if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
			    reply(dpuhy.wait())
			    const somtoy = sotoy[Math.floor(Math.random() * sotoy.length)]
			    dp.sendMessage(from, `[  🎰 | SLOTS ]\n-----------------\n🍋 : 🍌 : 🍍\n${somtoy}<=====\n🍋 : 🍌 : 🍍\n[  🎰 | SLOTS ]\n\nKeterangan : Jika anda Mendapatkan 3 Buah Sama Berarti Kamu Win\n\nContoh : 🍌 : 🍌 : 🍌<=====`, text, {quoted: fkontak})
			    await limitAdd(sender)
			    break
				case 'tebakgambar':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
				anu = await fetchJson(`https://dapuhy-api.herokuapp.com/api/fun/tebakgambar?apikey=${DapApi}`, {method: 'get'})
				ngebuff = await getBuffer(anu.result.image)
				tebak = `➸ Jawaban : ${anu.result.jawaban}`
				setTimeout( () => {
				dp.sendMessage(from, tebak, text, {quoted: fkontak})
				}, 30000)
				setTimeout( () => {
				dp.sendMessage(from, '_10 Detik lagi..._', text, {quoted: fkontak})
				}, 20000)
				setTimeout( () => {
				dp.sendMessage(from, '_20 Detik lagi..._', text, {quoted: fkontak})
				}, 10000)
				setTimeout( () => {
				dp.sendMessage(from, '_30 Detik lagi..._', text, {quoted: fkontak})
				}, 2500)
				setTimeout( () => {
				dp.sendMessage(from, ngebuff, image, {quoted: freply, caption: `clue : ${anu.result.clue}`})
				}, 0)
				await limitAdd(sender)
				break
				case 'tebakgambar2':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/tebakgambar?apikey=${LeysApi}`, {method: 'get'})
				ngebuff = await getBuffer(anu.result.img)
				tebak = `➸ Jawaban : ${anu.result.jawaban}`
				setTimeout( () => {
				dp.sendMessage(from, tebak, text, {quoted: fkontak})
				}, 30000)
				setTimeout( () => {
				dp.sendMessage(from, '_10 Detik lagi..._', text, {quoted: fkontak})
				}, 20000)
				setTimeout( () => {
				dp.sendMessage(from, '_20 Detik lagi..._', text, {quoted: fkontak})
				}, 10000)
				setTimeout( () => {
				dp.sendMessage(from, '_30 Detik lagi..._', text, {quoted: fkontak})
				}, 2500)
				setTimeout( () => {
				dp.sendMessage(from, ngebuff, image, { caption: '_Tebak bro!!! gak bisa jawab donasi ya:v_', quoted: freply })
				}, 0)
				await limitAdd(sender) 
				break
				case 'tebakgambar3':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/tebak-gambar2?apikey=${LeysApi}`, {method: 'get'})
				ngebuff = await getBuffer(anu.result.soal)
				tebak = `➸ Jawaban : ${anu.result.jawaban}`
				setTimeout( () => {
				dp.sendMessage(from, tebak, text, {quoted: fkontak})
				}, 30000)
				setTimeout( () => {
				dp.sendMessage(from, '_10 Detik lagi..._', text, {quoted: fkontak})
				}, 20000)
				setTimeout( () => {
				dp.sendMessage(from, '_20 Detik lagi..._', text, {quoted: fkontak})
				}, 10000)
				setTimeout( () => {
				dp.sendMessage(from, '_30 Detik lagi..._', text, {quoted: fkontak})
				}, 2500)
				setTimeout( () => {
				dp.sendMessage(from, ngebuff, image, { caption: '_Tebak bro!!! gak bisa jawab donasi ya:v_', quoted: freply })
				}, 0)
				await limitAdd(sender) 
				break
				case 'tebakkata':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/tebak-kata?apikey=${LeysApi}`, {method: 'get'})
				nebaksu = `${anu.result.soal}`
				tebak = `➸ Jawaban : ${anu.result.jawaban}`
				setTimeout( () => {
				dp.sendMessage(from, tebak, text, {quoted: fkontak})
				}, 30000)
				setTimeout( () => {
				dp.sendMessage(from, '_10 Detik lagi..._', text, {quoted: fkontak})
				}, 20000)
				setTimeout( () => {
				dp.sendMessage(from, '_20 Detik lagi..._', text, {quoted: fkontak})
				}, 10000)
				setTimeout( () => {
				dp.sendMessage(from, '_30 Detik lagi..._', text, {quoted: fkontak})
				}, 2500)
				setTimeout( () => {
				dp.sendMessage(from, nebaksu, text, {quoted: fkontak})
				}, 0)
				await limitAdd(sender) 
				break
			    case 'artinama':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                reply(dpuhy.wait())
                anu = await fetchJson(`http://zekais-api.herokuapp.com/artinama?nama=${body.slice(9)}`)
                dapuhy = `Nama : ${anu.name}\nArti : ${anu.result}`
                dp.sendMessage(from, dapuhy, text, {quoted: fkontak})
                await limitAdd(sender)
                break
                case 'truth':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				const trut =['Pernah suka sama siapa aja? berapa lama?','Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)','apa ketakutan terbesar kamu?','pernah suka sama orang dan merasa orang itu suka sama kamu juga?','Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?','pernah gak nyuri uang nyokap atau bokap? Alesanya?','hal yang bikin seneng pas lu lagi sedih apa','pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?','pernah jadi selingkuhan orang?','hal yang paling ditakutin','siapa orang yang paling berpengaruh kepada kehidupanmu','hal membanggakan apa yang kamu dapatkan di tahun ini','siapa orang yang bisa membuatmu sange','siapa orang yang pernah buatmu sange','(bgi yg muslim) pernah ga solat seharian?','Siapa yang paling mendekati tipe pasangan idealmu di sini','suka mabar(main bareng)sama siapa?','pernah nolak orang? alasannya kenapa?','Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget','pencapaian yang udah didapet apa aja ditahun ini?','kebiasaan terburuk lo pas di sekolah apa?']
				const ttrth = trut[Math.floor(Math.random() * trut.length)]
				truteh = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
				dp.sendMessage(from, truteh, image, { caption: 'Truth\n\n'+ ttrth, quoted: freply })
				await limitAdd(sender)
				break
				case 'dare':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				const dare =['Kirim pesan ke mantan kamu dan bilang "aku masih suka sama kamu','telfon crush/pacar sekarang dan ss ke pemain','pap ke salah satu anggota grup','Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo','ss recent call whatsapp','drop emot "🦄💨" setiap ngetik di gc/pc selama 1 hari','kirim voice note bilang can i call u baby?','drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu','pake foto sule sampe 3 hari','ketik pake bahasa daerah 24 jam','ganti nama menjadi "gue anak lucinta luna" selama 5 jam','chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you','prank chat mantan dan bilang " i love u, pgn balikan','record voice baca surah al-kautsar','bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini','sebutkan tipe pacar mu!','snap/post foto pacar/crush','teriak gajelas lalu kirim pake vn kesini','pap mukamu lalu kirim ke salah satu temanmu','kirim fotomu dengan caption, aku anak pungut','teriak pake kata kasar sambil vn trus kirim kesini','teriak " anjimm gabutt anjimmm " di depan rumah mu','ganti nama jadi " BOWO " selama 24 jam','Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll']
				const der = dare[Math.floor(Math.random() * dare.length)]
				tod = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
				dp.sendMessage(from, tod, image, { quoted: freply, caption: 'Dare\n\n'+ der })
				await limitAdd(sender)
				break
				case 'bisakah':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				bisakah = body.slice(1)
				const bisa =['Bisa','Tidak Bisa','Coba Ulangi']
				const keh = bisa[Math.floor(Math.random() * bisa.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+bisakah+'*\n\nJawaban : '+ keh, text, { quoted: fkontak })
				await limitAdd(sender)
				break
		        case 'kapankah':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				kapankah = body.slice(1)
				const kapan =['Besok','Lusa','1 Hari Lagi','2 Hari Lagi','3 Hari Lagi','4 Hari Lagi','5 Hari Lagi','6 Hari Lagi','1 Bulan Lagi','2 Bulan Lagi','3 Bulan Lagi','4 Bulan Lagi','5 Bulan Lagi','6 Bulan Lagi','7 Bulan Lagi','8 Bulan Lagi','9 Bulan Lagi','10 Bulan Lagi','11 Bulan Lagi','1 Tahun lagi','2 Tahun lagi','3 Tahun lag0i','4 Tahun lagi','5 Tahun lagi','6 Tahun lagi','7 Tahun lagi','8 Tahun lagi','9 Tahun lagi','10 Tahun lagi']
				const koh = kapan[Math.floor(Math.random() * kapan.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+kapankah+'*\n\nJawaban : '+ koh, text, { quoted: fkontak })
				await limitAdd(sender)
				break
		        case 'apakah':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				apakah = body.slice(1)
				const apa =['Iya','Tidak','Bisa Jadi','Coba Ulangi']
				const kah = apa[Math.floor(Math.random() * apa.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+apakah+'*\n\nJawaban : '+ kah, text, { quoted: fkontak })
				await limitAdd(sender)
				break
		        case 'bagaimanakah':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				bagaimanakah = body.slice(1)
				const bagai =['Kita Kenal?','Nanya Terus deh','Tidak Tahu','Coba Ulangi','Cari Aja Sendiri','Kurang Tahu','Mana Saya Tahu, Saya kan ikan']
				const mana = bagai[Math.floor(Math.random() * bagai.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+bagaimanakah+'*\n\nJawaban : '+ mana, text, { quoted: fkontak })
				await limitAdd(sender)
				break
		        case 'rate':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				rate = body.slice(1)
				const ra =['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
				const te = ra[Math.floor(Math.random() * ra.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+rate+'*\n\nJawaban : '+ te+'%', text, { quoted: fkontak })
				await limitAdd(sender)
				break
                case 'sangecek':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				sange = body.slice(1)
				const sang =['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
				const nge = sang[Math.floor(Math.random() * sang.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+sange+'*\n\nJawaban : '+ nge+'%', text, { quoted: fkontak })
				await limitAdd(sender)
				break
                case 'gaycek':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				gayy = body.slice(1)
				const gay =['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
				const yag = gay[Math.floor(Math.random() * gay.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+gayy+'*\n\nJawaban : '+ yag+'%', text, { quoted: fkontak })
				await limitAdd(sender)
				break
                case 'lesbicek':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				lesbii = body.slice(1)
				const lesbi =['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
				const bi = lesbi[Math.floor(Math.random() * lesbi.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+lesbii+'*\n\nJawaban : '+ bi+'%', text, { quoted: fkontak })
				await limitAdd(sender)
				break
                case 'gantengcek':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				ganteng = body.slice(1)
				const gan =['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
				const teng = gan[Math.floor(Math.random() * gan.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+ganteng+'*\n\nJawaban : '+ teng+'%', text, { quoted: fkontak })
				await limitAdd(sender)
				break
		        case 'cantikcek':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				cantik = body.slice(1)
				const can =['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
				const tik = can[Math.floor(Math.random() * can.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+cantik+'*\n\nJawaban : '+ tik+'%', text, { quoted: fkontak })
				await limitAdd(sender)
				break
		        case 'watak':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				watak = body.slice(1)
				const wa =['Penyayang','Pemurah','Pemarah','Pemaaf','Penurut','Baik','Baperan','Baik Hati','penyabar','UwU','top deh, pokoknya','Suka Membantu']
				const tak = wa[Math.floor(Math.random() * wa.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+watak+'*\n\nJawaban : '+ tak, text, { quoted: fkontak })
				await limitAdd(sender)
				break
		        case 'hobby':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				hobby = body.slice(1)
				const hob =['Memasak','Membantu Atok','Mabar','Nobar','Sosmedtan','Membantu Orang lain','Nonton Anime','Nonton Drakor','Naik Motor','Nyanyi','Menari','Bertumbuk','Menggambar','Foto fotoan Ga jelas','Maen Game','Berbicara Sendiri']
				const by = hob[Math.floor(Math.random() * hob.length)]
				dp.sendMessage(from, 'Pertanyaan : *'+hobby+'*\n\nJawaban : '+ by, text, { quoted: fkontak })
				await limitAdd(sender)
				break
                case 'jadian':
				if (!isGroup) return reply(dpuhy.groupo())
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				jds = []
				const jdii = groupMembers
				const koss = groupMembers
				const akuu = jdii[Math.floor(Math.random() * jdii.length)]
				const diaa = koss[Math.floor(Math.random() * koss.length)]
				teks = `Ciee.. yang lagi jadian @${akuu.jid.split('@')[0]} ♥️ @${diaa.jid.split('@')[0]} `
				jds.push(akuu.jid)
				jds.push(diaa.jid)
				mentions(teks, jds, true)
				await limitAdd(sender)
				break	
				case 'bug':
				dp.toggleDisappearingMessages(from, 0)
				break
				case 'ngewe':
				if (!isGroup) return reply(dpuhy.groupo())
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				jds = []
				const jdiid = groupMembers
				const kosst = groupMembers
				const akuut = jdiid[Math.floor(Math.random() * jdiid.length)]
				const diaat = kosst[Math.floor(Math.random() * kosst.length)]
				teks = `Yang ngewe kemarin di grub ini adalah @${akuut.jid.split('@')[0]} dan️ @${diaat.jid.split('@')[0]} `
				jds.push(akuut.jid)
				jds.push(diaat.jid)
				mentions(teks, jds, true)
				await limitAdd(sender)
				break	
			    case 'terganteng':
				if (!isGroup) return reply(dpuhy.groupo())
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				jds = []
				const jdiidc = groupMembers
				const kosstc = groupMembers
				const akuutc = jdiidc[Math.floor(Math.random() * jdiidc.length)]
				teks = `Yang terganteng di grub ini adalah @${akuutc.jid.split('@')[0]}`
				jds.push(akuutc.jid)
				mentions(teks, jds, true)
				await limitAdd(sender)
				break	
				case 'tercantik':
				if (!isGroup) return reply(dpuhy.groupo())
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
				jds = []
				const jdiidr = groupMembers
				const kosstr = groupMembers
				const akuutr = jdiidr[Math.floor(Math.random() * jdiidr.length)]
				teks = `Yang tercantik di grub ini adalah @${akuutr.jid.split('@')[0]}`
				jds.push(akuutr.jid)
				mentions(teks, jds, true)
				await limitAdd(sender)
				break
//==========================================BATES NGAB==========================================\\
//TOOLS MENU
                case 'base64encode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(14)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/base64/?encode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'base64decode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(14)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/base64/?decode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'base32hexencode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(17)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/base32hex/?encode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'base32hexdecode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(17)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/base32/?decode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'binaryencode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(14)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/binary/?encode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'binarydecode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(14)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/binary/?decode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'octalencode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(13)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/octal/?encode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'octaldecode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(13)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/octal/?decode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'hexencode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(13)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/hex/?encode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'hexdecode':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`textnya mana?`)
                txt = body.slice(13)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://api.anoncybfakeplayer.com/api/hex/?decode=${txt}`)
				teks = `Hasil : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
                case 'shortlink':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`Linknya mana su?\nContoh ${prefix}shortlink https://google.com`)
                link = body.slice(11)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/tinyurl?url=${link}&apikey=${LeysApi}`)
				teks = `SHORTLINK📊\n\nLink : ${link}\nHasil shortlink : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'shortlink2':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`Linknya mana su?\nContoh ${prefix}shortlink https://google.com`)
                link = body.slice(12)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/cuttly?url=${link}&apikey=${LeysApi}`)
				teks = `SHORTLINK📊\n\nLink : ${link}\nHasil shortlink : ${anu.result.hasil}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'shortlink3':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (isBanned) return reply(dpuhy.baned())
                if (args.length < 1) return reply(`Linknya mana su?\nContoh ${prefix}shortlink https://google.com`)
                link = body.slice(12)
                reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/shrturl?url=${link}&apikey=${LeysApi}`)
				teks = `SHORTLINK📊\n\nLink : ${link}\nHasil shortlink : ${anu.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
//==========================================BATES NGAB==========================================\\
//MEDIA MENU
				case 'nickff':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				data = await fetchJson(`https://leyscoders-api.herokuapp.com/api/nick-epep?apikey=${LeysApi}`)
				teks = `${data.result}`
				dp.sendMessage(from, teks, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				break
				case 'quotes':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/random/quotes?apikey=${LolHuman}`) 
				jam = `「 BY 」 : ${anu.result.by}\n\n「 QUOTES 」 : ${anu.result.quote}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'quotesdilan':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/quotes/dilan?apikey=${LolHuman}`) 
				jam = `「 QUOTES 」 :\n\n${anu.result}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'faktaunik':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/random/faktaunik?apikey=${LolHuman}`) 
				dapzz = `FAKTA UNIK : ${anu.result}`
				dp.sendMessage(from, dapzz, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'katakatabijak':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/random/katabijak?apikey=${LolHuman}`) 
				jam = `「 KATA KATA BIJAK 」 :\n\n${anu.result}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'randompantun':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/random/pantun?apikey=${LolHuman}`) 
				jam = `「 RANDOM PANTUN 」 :\n\n${anu.result}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'randombucin':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/random/bucin?apikey=${LolHuman}`) 
				jam = `「 RANDOM BUCIN 」 :\n\n${anu.result}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'katakatabucin':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/random/katabucin?apikey=${LolHuman}`) 
				jam = `「 KATA KATA BUCIN 」 :\n\n${anu.result}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'randomnama':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`http://api.lolhuman.xyz/api/random/nama?apikey=${LolHuman}`) 
				jam = `「 NAMA 」 :\n\n${anu.result}`
				dp.sendMessage(from, jam, text, {quoted: fkontak})
				await limitAdd(sender)
				break
				case 'memedpuhyo':
				case 'darkjoke':
				case 'estetik':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/${command}?apikey=${LeysApi}`) 
				oyy = await getBuffer(anu.result)
				dp.sendMessage(from, oyy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'ppcouple':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/ppcouple?apikey=${LeysApi}`) 
				cowo = await getBuffer(anu.result.male)
				dp.sendMessage(from, cowo, image, {quoted: freply})
				cewe = await getBuffer(anu.result.female)
				dp.sendMessage(from, cewe, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'ceritahoror':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`https://api.lolhuman.xyz/api/ceritahoror?apikey=${LolHuman}`)
				d = anu.result
				buffer = await getBuffer(d.thumbnail)
				horor = `[ CERITA HOROR ]\n\n\nTitle : ${d.title}\nDeskripsi : ${d.desc}\nStory : ${d.story}`
				dp.sendMessage(from, buffer, image, {quoted: freply, caption: horor})
				await limitAdd(sender)
				break
/*
DIKUNCI BRO KALO MAU BUKA BUKA AJA
TAPI DOSA TANGGUNG SENDIRI YA
				case 'cersex':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				reply(dpuhy.wait()) 
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/cersex?apikey=${LeysApi}`) 
				buffer = await getBuffer(anu.gambar)
				sex = `[ CERITA SEX ]\n\n\nCerita : ${anu.result}`
				dp.sendMessage(from, buffer, image, {quoted: freply, caption: sex})
				await limitAdd(sender)
				break
				case 'cersexsearch': 
                if (isBanned) return reply(dpuhy.wait())
                if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                judul = args.join(" ")
				reply(dpuhy.wait())
				anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/cersex-search?q=${judul}&apikey=${LeysApi}`, {method: 'get'})
				teks = '=================\n'
				for (let i of anu.result) {
				teks += `[ CERITA SEX SEARCH ]\n\n\nUrl : ${i.url}\nTitle : ${i.title}\nImage : ${i.img}\nCategory : ${i.category}\nPost : ${i.post}\n=================\n`
				}
				reply(teks.trim())
				await limitAdd(sender)
				break
*/
//==========================================BATES NGAB==========================================\\
//SPAM MENU
				case 'spamsms':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
			    if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh : ${prefix + command} 085123456789`)
                reply('[❗] Sabar lagi ngespam')
                nomor = args[0]
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam1?apikey=${LolHuman}&nomor=${nomor}`)
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam2?apikey=${LolHuman}&nomor=${nomor}`)
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam3?apikey=${LolHuman}&nomor=${nomor}`)
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam4?apikey=${LolHuman}&nomor=${nomor}`)
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam5?apikey=${LolHuman}&nomor=${nomor}`)
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam6?apikey=${LolHuman}&nomor=${nomor}`)
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam7?apikey=${LolHuman}&nomor=${nomor}`)
                await fetchJson(`http://api.lolhuman.xyz/api/sms/spam8?apikey=${LolHuman}&nomor=${nomor}`)
                reply("Success")
                await limitAdd(sender)
                break
                case 'spamcall':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args[0].startsWith('08')) return reply('Gunakan nomer awalan 8/n contoh : 85123456789')
                reply('[❗] Sabar lagi ngespam')
                dpp = body.slice(10)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                await fetchJson(`https://videfikri.com/api/call/?nohp=${dpp}`)
                reply("Success")
                await limitAdd(sender)
                break
                case 'spamgmail':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                reply('[❗] Sabar lagi ngespam')
                dpp = body.slice(11)
                dap1 = dpp.split("|")[0];
                dap2 = dpp.split("|")[1];
                dap3 = dpp.split("|")[2];
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                await fetchJson(`https://videfikri.com/api/spamemail/?email=${dap1}&subjek=${dap2}&pesan=${dap3}`)
                reply("Success")
                await limitAdd(sender)
                break
//==========================================BATES NGAB==========================================\\
//OTHER MENU
                case 'stiker': 
				case 'sticker':
				case 's':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                    await limitAdd(sender)
                    reply(dpuhy.wait())
					if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
						const media = await dp.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(dpuhy.stikga())
							})
							.on('end', function () {
								console.log('Finish')
								buffer = fs.readFileSync(ran)
								dp.sendMessage(from, buffer, sticker, {quoted: freply})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && dap.message.videoMessage.seconds < 11 || isQuotedVideo && dap.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
						const media = await dp.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(dpuhy.wait())
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(dpuhy.stikga())
							})
							.on('end', function () {
								console.log('Finish')
								buffer = fs.readFileSync(ran)
								dp.sendMessage(from, buffer, sticker, {quoted: freply})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
							} else {
						reply(`Kirim gambar/video/gif dengan caption \n${prefix}sticker (durasi sticker video 1-9 detik)`)
					}
					break
					case 'semoji': 
                    try {
				    if (!isUser) return reply(dpuhy.noregis())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pushname))
				    if (isBanned) return reply(dpuhy.baned())
                    if (args.length < 1) return reply(`emojinya mana?/ncontoh : ${prefix + command} 😭`) 
                    reply(dpuhy.wait())
                    emoji = args[0]
                    try {
                    emoji = encodeURI(emoji[0])
                    } catch {
                    emoji = encodeURI(emoji)
                    }
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/smoji3/${emoji}?apikey=${LolHuman}`) 
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/convert/towebpauthor?apikey=${LolHuman}&img=${ini_url.result.emoji.whatsapp}&package=@${namabot}&author=${namaowner}`)
                    dp.sendMessage(from, ini_buffer, sticker, { quoted: freply }) 
                    await limitAdd(sender)
                    } catch (e) {
				    console.log(`Error :`, color(e,'red'))
				    reply('❌ ERROR ❌')
				    }
                    break
                    case 'kontag':
                    if (!isUser) return reply(dpuhy.noregis())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pushname))
				    if (isBanned) return reply(dpuhy.baned())
                    if (args.length < 1) return reply(`cara : ${prefix + command} Dappa|19199992616`)
                    reply(dpuhy.wait())
                    const pepek = body.slice(8)
                    const adan = pepek.split("|")[0]
                    const nuahh = pepek.split("|")[1]
                    const trot = 
                    'BEGIN:VCARD\n' +
                    'VERSION:3.0\n' +
                    'FN:' + adan + '\n' +
                    'ORG:Kontak\n' +
                    'TEL;type=CELL;type=VOICE;waid=' + nuahh + ':+' + nuahh + '\n' +
                    'END:VCARD'
                    let taih = await dp.groupMetadata(from)
                    let setan = taih.participants
                    let bruy = []
                    for (let go of setan){
                    bruy.push(go.jid)
                    }
                    dp.sendMessage(from, {displayname: adan, vcard: trot}, MessageType.contact, {contextInfo: {"mentionedJid": bruy}})
                    await limitAdd(sender)
                    break
					case 'swm':
					case 'stickerwm':
					if (!isUser) return reply(dpuhy.noregis())
					if (isBanned) return reply(dpuhy.baned())
					if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                    if (type === 'imageMessage' || isQuotedImage){
                    var kls = body.slice(5)
                    var pack = kls.split("|")[0];
                    var author = kls.split("|")[1];
                    const getbuff = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
                    const dlfile = await dp.downloadMediaMessage(getbuff)
                    reply(dpuhy.wait())
                    const bas64 = `data:image/jpeg;base64,${dlfile.toString('base64')}`
                    var mantap = await convertSticker(bas64, `${author}`, `${pack}`)
                    var imageBuffer = new Buffer.from(mantap, 'base64');
                    dp.sendMessage(from, imageBuffer, MessageType.sticker, {quoted: freply})
                    } else {
                    reply('Format Salah!')
                    }
                    await limitAdd(sender)
                    break
					case 'fak':
					if (!isUser) return reply(dpuhy.noregis())
					if (isBanned) return reply(dpuhy.baned())
					if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
					cat = body.slice(5)
					dp.sendMessage(from, `${cat}`, text, { sendEphemeral: true, thumbnail: fs.readFileSync('./lib/logo.jpeg', 'base64')})
					await limitAdd(sender)
					break
				    case 'hekweb':
				    if (!isUser) return reply(dpuhy.noregis())
					if (isBanned) return reply(dpuhy.baned())
					if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				    var gas = body.slice(8)
				    if (isQuotedImage) {
					var linknya = gas.split("|")[0];
					var titlenya = gas.split("|")[1];
					var descnya = gas.split("|")[2];
					var jadinya = gas.split("|")[3];
					var imgbb = require('imgbb-uploader')
			 		run = getRandom('.jpeg')
					encmedia = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
					media = await dp.downloadAndSaveMediaMessage(encmedia)
					ddatae = await imageToBase64(JSON.stringify(media).replace(/\"/gi,''))
					dp.sendMessage(from, {text: `${linknya}`, matchedText: `${linknya}`, canonicalUrl: `${jadinya}`, description: `${descnya}`, title: `${titlenya}`, jpegThumbnail: ddatae}, 'extendedTextMessage', {detectLinks: false})
					} else if (isQuotedSticker) {
					var linknya = body.slice(8)
					encmedia = JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await dp.downloadAndSaveMediaMessage(encmedia)
					anu = fs.readFileSync(media)
					dp.sendMessage(from, {text: `${linknya}`, matchedText: `${linknya}`, canonicalUrl: `https://youtube.com/channel/UC7jjRVuhCG3qVySTL_l9dYQ`, description: `Hacked by ${pushname}`, title: `Terhemked :v`, jpegThumbnail: anu}, 'extendedTextMessage', {detectLinks: false})
					} else if (!isQuotedImage) {
					try {
					ppimg = await dp.getProfilePicture(sender)
					} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
					}
					ddatae = await imageToBase64(JSON.stringify(ppimg).replace(/\"/gi,''))
					dp.sendMessage(from, {text: `https://${gas}.com`, matchedText: `https://${gas}.com`, canonicalUrl: `https://${gas}.com`, description: `Hacked by ${pushname}`, title: `Terhemked :v`, jpegThumbnail: ddatae}, 'extendedTextMessage', {detectLinks: false}, {quoted : freply})
					}
					await limitAdd(sender)
					break
					case 'ambil':
					case 'colong':
					if (!isUser) return reply(dpuhy.noregis())
				    if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				    reply(dpuhy.wait())
					if ((isMedia && !dap.message.videoMessage || isQuotedSticker) && args.length == 0) {
						const encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
						const media = await dp.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata(`@${namabot}`,`${namaowner}`)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(dpuhy.stikga())
									dp.sendMessage(from, fs.readFileSync(ran), sticker, { quoted: { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "393470602054-1351628616@g.us" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `${YahahaHayyuk}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('./lib/logo.jpeg')} } } })
									fs.unlinkSync(media)	
									fs.unlinkSync(ran)	
								})
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && dap.message.videoMessage.seconds < 11 || isQuotedVideo && dap.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
						const media = await dp.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`❌ Gagal, pada saat mengkonversi ${tipe} ke stiker`)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata(`@${namabot}`,`${namaowner}`)} ${ran} -o ${ran}`, async (error) => {
									if (error) return reply(dpuhy.stikga())
									dp.sendMessage(from, fs.readFileSync(ran), sticker, { quoted: { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "393470602054-1351628616@g.us" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `${YahahaHayyuk}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('./lib/logo.jpeg')} } } })
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedSticker) && args[0] == 'nobg') {
						const encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
						const media = await dp.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						keyrmbg = 'Your-ApiKey'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('Gagal, Terjadi kesalahan, silahkan coba beberapa saat lagi.')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								exec(`webpmux -set exif ${addMetadata('BOT', authorname)} ${ranw} -o ${ranw}`, async (error) => {
									dp.sendMessage(from, fs.readFileSync(ranw), sticker, { quoted: { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "393470602054-1351628616@g.us" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `${YahahaHayyuk}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('./lib/logo.jpeg')} } } })
									fs.unlinkSync(ranw)
								})
							})
						})
					} else {
						reply(`reply sticker dengan caption ${prefix}colong`)
					}
					await limitAdd(sender)
					break
					case 'takestick':
					if (!isUser) return reply(dpuhy.noregis())
				    if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
					if (!isQuotedSticker) return reply(`Reply sticker dengan caption ${prefix}takestick nama|author`)
					var pembawm = body.slice(6)
					var encmedia = JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					var media = await dp.downloadAndSaveMediaMessage(encmedia, `./sticker/${sender}`)
					var packname = pembawm.split('|')[0]
					var author = pembawm.split('|')[1]
					exif.create(packname, author, `takestick_${sender}`)
					exec(`webpmux -set exif ./sticker/takestick_${sender}.exif ./sticker/${sender}.webp -o ./sticker/${sender}.webp`, async (error) => {
					if (error) return reply(dpuhy.stikga())
					dp.sendMessage(from, fs.readFileSync(`./sticker/${sender}.webp`), MessageType.sticker, {quoted: freply})
					fs.unlinkSync(media)
					fs.unlinkSync(`./sticker/takestick_${sender}.exif`)
					})
					await limitAdd(sender)
					break
					case 'subdo':
                    case 'nmap':
                    if (!isUser) return reply(dpuhy.noregis())
				    if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				    reply(dpuhy.wait())
                    web = args.join(" ")
                    kntl = await fetchJson(`http://jamet1337.ml/api/${command}.php?url=${web}`)
                    ambil = (kntl.hasil)
                    dp.sendMessage(from, ambil, text, {quoted: fkontak})
                    await limitAdd(sender)
                    break
                    case 'viewsource':
                    if (!isUser) return reply(dpuhy.noregis())
				    if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				    reply(dpuhy.wait())
                    web = args.join(" ")
                    kntl = await fetchJson(`https://pencarikode.xyz/html?url=${web}&apikey=Tester`)
                    ambil = (kntl.html)
                    dp.sendMessage(from, ambil, text, {quoted: fkontak})
                    await limitAdd(sender)
                    break
                    break
                    case 'ocr': 
				    if (!isUser) return reply(dpuhy.noregis())
				    if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				    if ((isMedia && !dap.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
						const media = await dp.downloadAndSaveMediaMessage(encmedia)
						reply(dpuhy.wait())
						await recognize(media, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(teks => {
								reply(teks.trim())
								fs.unlinkSync(media)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(media)
							})
					} else {
						reply(`kirim gambar bertulisan dengan caption ${prefix + command}`)
					}
					await limitAdd(sender)
					break
					case 'toimg':
				    if (!isUser) return reply(dpuhy.noregis())
				    if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				    if (!isQuotedSticker) return reply('reply stickernya ngab')
					reply(dpuhy.wait())
					encmedia = JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await dp.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply(dpuhy.stikga())
						buffer = fs.readFileSync(ran)
						dp.sendMessage(from, buffer, image, {quoted: freply})
						fs.unlinkSync(ran)
					})
					await limitAdd(sender)
					break
					case 'spatrick':
					if (!isUser) return reply(dpuhy.noregis())
			    	if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				    reply(dpuhy.wait())
					dppa = await getBuffer(`https://api.lolhuman.xyz/api/sticker/patrick?apikey=${LolHuman}`)
					dp.sendMessage(from, dppa, sticker, {quoted: freply})
					await limitAdd(sender)
					break
					case 'telesticker':
				    if (!isUser) return reply(dpuhy.noregis())
			    	if (isBanned) return reply(dpuhy.baned())
				    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                    if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh : ${prefix + command} https://t.me/addstickers/LINE_Menhera_chan_ENG`)
                    reply(dpuhy.wait())
                    ini_url = args[0]
                    ini_url = await fetchJson(`http://api.lolhuman.xyz/api/telestick?apikey=${LolHuman}&url=${ini_url}`)
                    ini_sticker = ini_url.result.sticker
                    for (sticker_ in ini_sticker) {
                        ini_buffer = await getBuffer(ini_sticker[sticker_])
                        dp.sendMessage(from, ini_buffer, sticker)
                    }
                    await limitAdd(sender)
                    break
					case 'ssweb':
					case 'sswebfull':
                    if (!isUser) return reply(dpuhy.noregis())
                    if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                    if (isBanned) return reply(dpuhy.baned())
                    if (args.length < 1) return reply(`urlnya mana bruh?\ncontoh ${prefix + command} https://dapuhy-api.herokuapp.com`)
                    dppa = args.join(" ")
                    reply(dpuhy.wait())
                    dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=${LolHuman}&url=${dppa}`)
                    dp.sendMessage(from, dapuhy, image, {quoted: freply})
                    await limitAdd(sender)
                    break
//==========================================BATES NGAB==========================================\\
//SERTIFIKAT MENU
				case 'tololserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}tololserti ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://sertifikat-generator.000webhostapp.com/serti1/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fuckboyserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}`)
				reply(dpuhy.wait())
				dppa = args.join(" ")
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/fuckboy?apikey=${LolHuman}&name=${dppa}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fuckgirlserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}`)
				reply(dpuhy.wait())
				dppa = args.join(" ")
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/fuckgirl?apikey=${LolHuman}&name=${dppa}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'bucinserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}`)
				reply(dpuhy.wait())
				dppa = args.join(" ")
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/bucinserti?apikey=${LolHuman}&name=${dppa}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pacarserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}|${namaowner}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dap1 = ct.split("|")[0];
				dap2 = ct.split("|")[1];
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/pacarserti?apikey=${LolHuman}&name1=${dap1}&name2=${dap2}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'goodboyserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}`)
				reply(dpuhy.wait())
				dppa = args.join(" ")
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/goodboy?apikey=${LolHuman}&name=${dppa}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'goodgirlserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}`)
				reply(dpuhy.wait())
				dppa = args.join(" ")
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/goodgirl?apikey=${LolHuman}&name=${dppa}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'badboyserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}`)
				reply(dpuhy.wait())
				dppa = args.join(" ")
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/badboy?apikey=${LolHuman}&name=${dppa}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'badgirlserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix + command} ${pushname}`)
				reply(dpuhy.wait())
				dppa = args.join(" ")
				dapuhy = await getBuffer(`https://api.lolhuman.xyz/api/badgirl?apikey=${LolHuman}&name=${dppa}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'hekelserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}hekel ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/HekerSerti/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fftourserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}fftourserti ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/FFSerti/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fftourserti2':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}fftourserti2 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/FFSerti2/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fftourserti3':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}fftourserti3 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/FFSerti3/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fftourserti4':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}fftourserti4 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/FFSerti4/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'fftourserti5':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}fftourserti5 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/FFSerti5/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'mltourserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}mltourserti ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/MLTourSerti/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'mltourserti2':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}mltourserti2 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/MLTourSerti2/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'mltourserti3':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}mltourserti3 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/MLTourSerti3/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'mltourserti4':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}mltourserti4 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/MLTourSerti4/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'mltourserti5':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}mltourserti5 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/MLTourSerti5/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pubgtourserti':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}pubgtourserti ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/PubgTourSerti/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pubgtourserti2':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}pubgtourserti2 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/PubgTourSerti2/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pubgtourserti3':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}pubgtourserti3 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/PubgTourSerti3/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pubgtourserti4':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}pubgtourserti4 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/PubgTourSerti4/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
				case 'pubgtourserti5':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				if (args.length < 1) return reply(`Textnya Mana Cuy?\nContoh ${prefix}pubgtourserti5 ${pushname}`)
				reply(dpuhy.wait())
				ct = args.join(" ")
				dapuhy = await getBuffer(`https://onlydevcity.xyz/PubgTourSerti5/img.php?nama=${ct}`)
				dp.sendMessage(from, dapuhy, image, {quoted: freply})
				await limitAdd(sender)
				break
//==========================================BATES NGAB==========================================\\
//GROUP MENU
				case 'nobadword':
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (args.length < 1) return reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
                if (args[0] === '1') {
                if (isBadWord) return reply('Fitur BadWord sudah aktif sebelum nya')
                badword.push(from)
                fs.writeFileSync('./database/badword.json', JSON.stringify(badword))
                reply(`Fitur Badword Enable!`)
              	} else if (args[0] === '0') {
                badword.splice(from, 1)
                fs.writeFileSync('./database/badword.json', JSON.stringify(badword))
                reply(`Fitur Badword Disable`)
                } else {
                reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
                }
                break
				case 'setname':
		        if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				dp.groupUpdateSubject(from, `${body.slice(9)}`)
				dp.sendMessage(from, 'Succes, Ganti Nama Grup', text, {quoted: fkontak})
				break
                case 'setdesc':
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                dp.groupUpdateDescription(from, `${body.slice(9)}`)
                dp.sendMessage(from, 'Succes, Ganti Deskripsi Grup', text, {quoted: fkontak})
                break
                case 'demote':
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (dap.message.extendedTextMessage === undefined || dap.message.extendedTextMessage === null) return reply('Tag target yang ingin di turunkan admin group!')
                mentioned = dap.message.extendedTextMessage.contextInfo.mentionedJid
                if (mentioned.length > 1) {
                teks = ''
                for (let _ of mentioned) {
                teks += `Perintah diterima, menurunkan jadi admin group :\n`
                teks += `@_.split('@')[0]`
                }
                mentions(teks, mentioned, true)
                dp.groupDemoteAdmin(from, mentioned)
                } else {
                mentions(`Perintah diterima, menurunkan @${mentioned[0].split('@')[0]} jadi admin group`, mentioned, true)
                dp.groupDemoteAdmin(from, mentioned)
                }
                break
			    case 'promote':
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (dap.message.extendedTextMessage === undefined || dap.message.extendedTextMessage === null) return reply('Tag target yang ingin di jadikan admin group!')
                mentioned = dap.message.extendedTextMessage.contextInfo.mentionedJid
                if (mentioned.length > 1) {
                teks = ''
                for (let _ of mentioned) {
                teks += `Selamat 🥳 Anda naik menjadi admin group 🎉 :\n`
                teks += `@_.split('@')[0]`
                }
                mentions(teks, mentioned, true)
                dp.groupMakeAdmin(from, mentioned)
                } else {
                mentions(`Selamat 🥳 @${mentioned[0].split('@')[0]} Anda naik menjadi admin group 🎉`, mentioned, true)
                dp.groupMakeAdmin(from, mentioned)
                }
                break
                case 'kickall':
                dp.updatePresence(from, Presence.composing) 
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                members_id = groupMembers.map(v => v.jid)
                mentioned = members_id
                using = mentioned.filter(u => !(u == dap.key.fromMe || u.includes(dp.user.jid)))
                for (let member of using) {
                if (member.endsWith('@s.whatsapp.net')) 
                await delay(3000)
                await dp.groupRemove(from, members_id)
                }
                await sendMess(from, 'sukses kick all member')
                addFilter(sender)
			    break
		        case 'kick':
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (dap.message.extendedTextMessage === undefined || dap.message.extendedTextMessage === null) return reply('𝗧𝗮𝗴 𝘁𝗮𝗿𝗴𝗲𝘁 ??𝗮𝗻𝗴 𝗶𝗻𝗴𝗶𝗻 𝗱𝗶 𝘁𝗲𝗻𝗱𝗮𝗻𝗴!')
                mentioned = dap.message.extendedTextMessage.contextInfo.mentionedJid
                if (mentioned.length > 1) {
                teks = ''
                for (let _ of mentioned) {
                teks += `Asek jatah kick, otw kick 🤭 :\n`
                teks += `@_.split('@')[0]`
                }
                mentions(teks, mentioned, true)
                dp.groupRemove(from, mentioned)
                } else {
                mentions(`Asek jatah kick, otw kick @${mentioned[0].split('@')[0]} 🤭`, mentioned, true)
                dp.groupRemove(from, mentioned)
                }
                break
	        	case 'add':
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (args.length < 1) return reply('Yang mau di add jin ya?')
                if (args[0].startsWith('08')) return reply('Gunakan kode negara kak')
                try {
                num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
                dp.groupAdd(from, [num])
                } catch (e) {
                console.log('Error :', e)
                reply('Gagal menambahkan target, mungkin karena di private')
                }
                break
                case 'linkgc':
				if (!isGroup) return reply(dpuhy.groupo())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
				linkgc = await dp.groupInviteCode (from)
				yeh = `https://chat.whatsapp.com/${linkgc}\n\nlink Group ${groupName}`
				dp.sendMessage(from, yeh, text, {quoted: freply})
				await limitAdd(sender)
				break
				case 'hidetag':
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (!isGroup) return reply(dpuhy.groupo())
                var value = body.slice(8)
                var group = await dp.groupMetadata(from)
                var member = group['participants']
                var mem = []
                member.map( async adm => {
                mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
                })
                var options = {
                text: value,
                contextInfo: { mentionedJid: mem },
                quoted: dap
                }
                dp.sendMessage(from, options, text, {quoted: fkontak})
                await limitAdd(sender)
                break
                case 'level':
				if (!isUser) return reply(dpuhy.noregis())
				if (isBanned) return reply(dpuhy.baned())
				if (isLimit(sender)) return reply(dpuhy.limitend(pusname))
                if (!isLevelingOn) return reply(dpuhy.lvlnoon())
                if (!isGroup) return reply(dpuhy.groupo())
                const userLevel = getLevelingLevel(sender)
                const userXp = getLevelingXp(sender)
                if (userLevel === undefined && userXp === undefined) return reply(dpuhy.lvlnul())
                const requiredXp = 5000 * (Math.pow(2, userLevel) - 1)
                resul = `┏━━❉ LEVEL ❉━━\n┣⊱ Nama : ${pushname}\n┣⊱ Nomor : wa.me/${sender.split("@")[0]}\n┣⊱ User XP :  ${userXp}/${requiredXp}\n┣⊱ User Level : ${userLevel}\n┗━━━━━━━━━━━━`
                dp.sendMessage(from, resul, text, { quoted: dap})
                .catch(async (err) => {
                console.error(err)
                await reply(`Error!\n${err}`)
                })
				break
				case 'mining':
                if (!isUser) return reply(dpuhy.noregis())
                if (isLimit(sender)) return reply(dpuhy.limitend(pushname))
                if (isBanned) return reply(dpuhy.baned())
                if (!isGroup) return reply(dpuhy.groupo())
                if (!isEventon) return reply(`maaf ${pushname} event mining tidak di aktifkan oleh owner`)
                if (dap.key.fromMe) {
                const one = 99999
                addLevelingXp(sender, one)
                addLevelingLevel(sender, 99)
                reply(`Nih Untukmu Owner♥ ${one}Xp `)
                }else{
                const mining = Math.ceil(Math.random() * 16)
                addLevelingXp(sender, mining)
                await reply(`selamat ${namaowner} kamu mendapatkan ${mining}Xp`)
                }
                await limitAdd(sender)
				break
		        case 'grup':
		        case 'group':
                if (!isGroup) return reply(dpuhy.groupo())
                if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (args[0] === 'buka') {
				reply(`BERHASIL MEMBUKA GROUP`)
                dp.groupSettingChange(from, GroupSettingChange.messageSend, false)
                } else if (args[0] === 'tutup') {
                reply(`BERHASIL MENUTUP GROUP`)
				dp.groupSettingChange(from, GroupSettingChange.messageSend, true)
                }
                break
//==========================================BATES NGAB==========================================\\
//OWNER MENU
				case 'antilink':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
		        if (!isGroup) return reply(dpuhy.groupo())					
				if (args.length < 1) return reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				if (Number(args[0]) === 1) {
				if (isAntiLink) return reply(`[❗] Fitur ${command} sudah aktif`)
				antilink.push(from)
				fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink))
				reply(`[❗] Berhasil mengaktifkan fitur ${command} pada group ini`)
				dp.sendMessage(from,`PERINGATAN!! jika bukan admin kirim link wajib menggunakan #izinadmin`, text, {quoted: fkontak})
				} else if (Number(args[0]) === 0) {
				if (!isAntiLink) return reply(`[❗] Fitur ${command} sudah aktif`)
				var ini = anti.botLangsexOf(from)
				antilink.splice(ini, 1)
				fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink))
				reply(`[❗] Berhasil menonaktifkan fitur ${command} pada group ini`)
				} else {
				reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				}
				break
			    case 'public':
          	    if (!dap.key.fromMe) return reply(dpuhy.ownerb())
          	    if (banChats === false) return
          	    uptime = process.uptime()
          	    anu  = {contextInfo:{'stanzaId': "B826873620DD5947E683E3ABE663F263", 'participant': `${nomerlu}@s.whatsapp.net`, 'remoteJid': '6283136505591-1614953337@g.us', 'quotedMessage': {"imageMessage": {"caption": `「 𝐑𝐔𝐍𝐓𝐈𝐌𝐄 」\n${kyun(uptime)}`, 'jpegThumbnail': fs.readFileSync('./lib/logo.jpeg')}}}}
          	    banChats = false
          	    dp.sendMessage(from, `「 PUBLIC-MODE 」`, text,anu)
          	    break
		        case 'self':
          	    if (!dap.key.fromMe) return reply(dpuhy.ownerb())
          	    if (banChats === true) return
          	    uptime = process.uptime()
         	    anu  = {contextInfo:{'stanzaId': "B826873620DD5947E683E3ABE663F263", 'participant': `${nomerlu}@s.whatsapp.net`, 'remoteJid': '6283136505591-1614953337@g.us', 'quotedMessage': {"imageMessage": {"caption": `「 𝐑𝐔𝐍𝐓𝐈𝐌𝐄 」\n${kyun(uptime)}`, 'jpegThumbnail': fs.readFileSync('./lib/logo.jpeg')}}}}
         	    banChats = true
          	    dp.sendMessage(from, `「 SELF-MODE 」`, text,anu)
          	    break
          	    case 'setthumb':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (!isQuotedImage) return reply('reply image nya kak!')
                const dappa = JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
                const uhuy = await dp.downloadMediaMessage(dappa)
                fs.unlinkSync(`./lib/logo.jpeg`)
                await sleep(2000)
                fs.writeFileSync(`./lib/logo.jpeg`, uhuy)
                dp.sendMessage(from, 'Sukses Ngab!!', text, { sendEphemeral: true, thumbnail: fs.readFileSync('./lib/logo.jpeg', 'base64')})
                break
				case 'antivirtex':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
		        if (!isGroup) return reply(dpuhy.groupo())					
				if (args.length < 1) return reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				if (Number(args[0]) === 1) {
				if (isAntiVirtex) return reply(`[❗] Fitur ${command} sudah aktif`)
				antivirtex.push(from)
				fs.writeFileSync('./database/antivirtex.json', JSON.stringify(antivirtex))
				reply(`[❗] Berhasil mengaktifkan fitur ${command} pada group ini`)
				} else if (Number(args[0]) === 0) {
				if (!isAntiVirtex) return reply(`[❗] Fitur ${command} sudah aktif`)
				var ini = anti.botLangsexOf(from)
				antivirtex.splice(ini, 1)
				fs.writeFileSync('./database/antivirtex.json', JSON.stringify(antivirtex))
				reply(`[❗] Berhasil menonaktifkan fitur ${command} pada group ini`)
				} else {
				reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				}
				break
                case 'antidelete':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				const dataRevoke = JSON.parse(fs.readFileSync('./src/gc-revoked.json'))
				const dataCtRevoke = JSON.parse(fs.readFileSync('./src/ct-revoked.json'))
				const dataBanCtRevoke = JSON.parse(fs.readFileSync('./src/ct-revoked-banlist.json'))
				const isRevoke = dataRevoke.includes(from)
				const isCtRevoke = dataCtRevoke.data
				const isBanCtRevoke = dataBanCtRevoke.includes(sender) ? true : false
				const argz = body.split(' ')
				if (argz.length === 1) return dp.sendMessage(from, `Penggunaan fitur antidelete :\n\n${prefix}antidelete [aktif/mati] (Untuk grup)\n${prefix}antidelete [ctaktif/ctmati] (untuk semua kontak)\n${prefix}antidelete banct 628558xxxxxxx (banlist kontak)`, MessageType.text, {quoted: fkontak})
				if (argz[1] == 'aktif') {
					if (isGroup) {
						if (isRevoke) return dp.sendMessage(from, `Antidelete telah diaktifkan di grup ini sebelumnya!`, MessageType.text, {quoted: fkontak})
						dataRevoke.push(from)
						fs.writeFileSync('./src/gc-revoked.json', JSON.stringify(dataRevoke, null, 2))
						dp.sendMessage(from, `Succes Enable Antidelete Grup!`, MessageType.text, {quoted: fkontak})
					} else if (!isGroup) {
						dp.sendMessage(from, `Untuk kontak penggunaan ${prefix}antidelete ctaktif`, MessageType.text, {quoted: fkontak})
					}
				} else if (argz[1] == 'ctaktif') {
					if (!isGroup) {
						if (isCtRevoke) return dp.sendMessage(from, `Antidelete telah diaktifkan di semua kontak sebelumnya!`, MessageType.text, {quoted: fkontak})
						dataCtRevoke.data = true
						fs.writeFileSync('./src/ct-revoked.json', JSON.stringify(dataCtRevoke, null, 2))
						dp.sendMessage(from, `Antidelete diaktifkan disemua kontak!`, MessageType.text, {quoted: fkontak})
					} else if (isGroup) {
						dp.sendMessage(from, `Untuk grup penggunaan ${prefix}antidelete aktif`, MessageType.text, {quoted: fkontak})
					}
				} else if (argz[1] == 'banct') {
					if (isBanCtRevoke) return dp.sendMessage(from, `kontak ini telah ada di database banlist!`, MessageType.text, {quoted: fkontak})
					if (argz.length === 2 || argz[2].startsWith('0')) return dp.sendMessage(from, `Masukan nomer diawali dengan 62! contoh 62859289xxxxx`, MessageType.text, {quoted: fkontak})
					dataBanCtRevoke.push(argz[2] + '@s.whatsapp.net')
					fs.writeFileSync('./src/ct-revoked-banlist.json', JSON.stringify(dataBanCtRevoke, null, 2))
					dp.sendMessage(from, `Kontak ${argz[2]} telah dimasukan ke banlist antidelete secara permanen!`, MessageType.text, {quoted: fkontak})
				} else if (argz[1] == 'mati') {
					if (isGroup) {
						const dpuhyex = dataRevoke.dpuhyexOf(from)
						dataRevoke.splice(dpuhyex, 1)
						fs.writeFileSync('./src/gc-revoked.json', JSON.stringify(dataRevoke, null, 2))
						dp.sendMessage(from, `Succes disable Antidelete Grup!`, MessageType.text, {quoted: fkontak})
					} else if (!isGroup) {
						dp.sendMessage(from, `Untuk kontak penggunaan ${prefix}antidelete ctmati`, MessageType.text, {quoted: fkontak})
					}
				} else if (argz[1] == 'ctmati') {
					if (!isGroup) {
						dataCtRevoke.data = false
						fs.writeFileSync('./src/ct-revoked.json', JSON.stringify(dataCtRevoke, null, 2))
						dp.sendMessage(from, `Antidelete dimatikan disemua kontak!`, MessageType.text, {quoted: fkontak})
					} else if (isGroup) {
						dp.sendMessage(from, `Untuk grup penggunaan ${prefix}antidelete mati`, MessageType.text, {quoted: fkontak})
					}
				}
				break
				case 'nsfw':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				if (Number(args[0]) === 1) {
				if (isNsfw) return reply(`[❗] Fitur ${command} sudah aktif`)
				nsfw.push(from)
				fs.writeFileSync('./database/nsfw.json', JSON.stringify(nsfw))
				reply(`[❗] Berhasil mengaktifkan fitur ${command} pada group ini`)
				} else if (Number(args[0]) === 0) {
						nsfw.splice(from, 1)
						fs.writeFileSync('./database/nsfw.json', JSON.stringify(nsfw))
						reply(`[❗] Berhasil menonaktifkan fitur ${command} pada group ini`)
					} else {
						reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
					}
				break
                case 'leveling':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (args.length < 1) return reply('[❗] Tambahkan parameter enable untuk mengaktifkan dan disable untuk menonaktifkan')
                if (args[0] === 'enable') {
                    if (isLevelingOn) return reply(`[❗] Fitur ${command} sudah aktif`)
                    _leveling.push(from)
                    fs.writeFileSync('./database/leveling.json', JSON.stringify(_leveling))
                     reply(`[❗] Berhasil mengaktifkan fitur ${command} pada group ini`)
                } else if (args[0] === 'disable') {
                    _leveling.splice(from, 1)
                    fs.writeFileSync('./database/leveling.json', JSON.stringify(_leveling))
                     reply(`[❗] Berhasil menonaktifkan fitur ${command} pada group ini`)
                } else {
                    reply('[❗] Tambahkan parameter enable untuk mengaktifkan dan disable untuk menonaktifkan')
                }
				break
				case 'welcome':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				if (Number(args[0]) === 1) {
						if (isWelkom) return reply(`[❗] Fitur ${command} sudah aktif`)
						welkom.push(from)
						fs.writeFileSync('./database/welkom.json', JSON.stringify(welkom))
						reply(`[❗] Berhasil mengaktifkan fitur ${command} pada group ini`)
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, 1)
						fs.writeFileSync('./database/welkom.json', JSON.stringify(welkom))
						reply(`[❗] Berhasil menonaktifkan fitur ${command} pada group ini`)
					} else {
						reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
					}
				break
                case 'event':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				if (Number(args[0]) === 1) {
				if (isEventon) return reply(`[❗] Fitur ${command} sudah aktif`)
				event.push(from)
				fs.writeFileSync('./database/event.json', JSON.stringify(event))
				reply(`[❗] Berhasil mengaktifkan fitur ${command} pada group ini`)
				} else if (Number(args[0]) === 0) {
				event.splice(from, 1)
				fs.writeFileSync('./database/event.json', JSON.stringify(event))
				reply(`[❗] Berhasil menonaktifkan fitur ${command} pada group ini`)
				} else {
				reply('[❗] Tambahkan parameter 1 untuk mengaktifkan dan 0 untuk menonaktifkan')
				}
				break
				case 'clone':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return reply('TAG YANG MAU DI CLONE!!!')
				if (dap.message.extendedTextMessage === undefined || dap.message.extendedTextMessage === null) return reply('Tag cvk')
				mentioned = dap.message.extendedTextMessage.contextInfo.mentionedJid[0]
				let { jid, id, notify } = groupMembers.fdpuhy(x => x.jid === mentioned)
				try {
				pp = await dp.getProfilePicture(id)
				buffer = await getBuffer(pp)
				dp.updateProfilePicture(botNumber, buffer)
				mentions(`Foto profile Berhasil di perbarui menggunakan foto profile @${id.split('@')[0]}`, [jid], true)
				} catch (e) {
				reply(dpuhy.stikga())
				}
				await limitAdd(sender)
				break
				case 'bc':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return reply('pesannya mana?')
				anu = await dp.chats.all()
				broadcast = args.join(' ')
				if (isMedia && !dap.message.videoMessage || isQuotedImage) {
				const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
				buff = await dp.downloadMediaMessage(encmedia)
				for (let _ of anu) {
			    await require('delay')(3000)
				await dp.sendMessage(_.jid, buff, image, {caption: `「 ${namabot} BROADCAST 」\n\n${broadcast}`, contextInfo: { mentionedJid: [sender] }})
				}
				} else {
				for (let _ of anu) {
				await require('delay')(3000)
				await dp.sendMessage(_.jid, `「 ${namabot} BROADCAST 」\n\n${broadcast}`, text, { contextInfo: { mentionedJid: [sender] }})
				}
				reply('Suksess broadcast')
				}
		        addFilter(sender)
			    break
				case 'bcgc':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return reply('pesannya mana?')
				anu = await groupMembers
				nom = anu.participant
			    if (isMedia && !dap.message.videoMessage || isQuotedImage) {
				const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(cok).replace('quotedM','m')).message.extendedTextMessage.contextInfo : dap
				bufferzzz = await dp.downloadMediaMessage(encmedia)
				for (let _ of anu) {
				dp.sendMessage(_.jid, bufferzzz, image, {caption: `「 BC GROUP 」\n\nDari Grup : ${groupName}\nPengirim : wa.me/${(sender.split('@')[0])}\nPesan : ${body.slice(6)}`})
				}
				reply('')
				} else {
				for (let _ of anu) {
				sendMess(_.jid, `「 BC GROUP 」\n\nDari Grup : ${groupName}\nPengirim : wa.me/${(sender.split('@')[0])}\nPesan : ${body.slice(6)}`)
				}
				reply('Sukses broadcast group')
				}
				break
				case 'block':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				dp.updatePresence(from, Presence.composing) 
				dp.chatRead (from)
				dp.blockUser (`${body.slice(7)}@c.us`, "add")
				dp.sendMessage(from, `Perintah Diterima, Memblokir ${body.slice(7)}@c.us`, text, {quoted: fkontak})
				break
		        case 'unblock':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				dp.blockUser (`${body.slice(9)}@c.us`, "remove")
			    dp.sendMessage(from, `Perintah Diterima, Membuka Blockir ${body.slice(9)}@c.us`, text, {quoted: fkontak})
				break
				case 'leave':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				setTimeout( () => {
				dp.groupLeave (from) 
				}, 2000)
				setTimeout( () => {
				dp.updatePresence(from, Presence.composing) 
				dp.sendMessage(from, 'Bye cuk disuruh keluar ama Ownerku🗣', text, {quoted: fkontak})
				}, 0)
				break
				case 'tagall':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				members_id = []
				teks = (args.length > 1) ? body.slice(8).trim() : ''
				teks += '\n\n'
				for (let mem of groupMembers) {
				teks += `➡️ @${mem.jid.split('@')[0]}\n`
				members_id.push(mem.jid)
				}
				mentions(teks, members_id, true)
				break
				case 'listvn':
			    case 'vnlist':
			    if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				teks = 'List Vn:\n\n'
				for (let awokwkwk of audionye) {
					teks += `- ${awokwkwk}\n`
				}
				teks += `\nTotal : ${audionye.length}`
				dp.sendMessage(from, teks.trim(), extendedText, {  quoted: { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "393470602054-1351628616@g.us" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `${YahahaHayyuk}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('lib/logo.jpeg')} } }, contextInfo: { "mentionedJid": audionye } })
				break
				case 'addvn':
			    if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (!isQuotedAudio) return reply('reply vnnya')
				svst = body.slice(7)
				if (!svst) return reply('Nama audionya apa su?')
				boij = JSON.parse(JSON.stringify(dap).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
				delb = await dp.downloadMediaMessage(boij)
				audionye.push(`${svst}`)
				fs.writeFileSync(`./src/audio/${svst}.mp3`, delb)
				fs.writeFileSync('./database/audio.json', JSON.stringify(audionye))
				dp.sendMessage(from, `mengsukses bruh ceknya jetik ${prefix}listvn`, MessageType.text, { quoted: { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "393470602054-1351628616@g.us" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `${YahahaHayyuk}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('lib/logo.jpeg')} } } }) 
				await limitAdd(sender)
				break
			    case 'getvn':
			    if (!dap.key.fromMe) return reply(dpuhy.ownerb())
			    if (args.length < 1) return reply('Masukan nama yang terdaftar di list vn')
				namastc = body.slice(7)
				buffer = fs.readFileSync(`./src/audio/${namastc}.mp3`)
				dp.sendMessage(from, buffer, audio, { mimetype: 'audio/mp4',  quoted: { key: { fromMe: false, participant: `${nomerlu}@s.whatsapp.net`, ...(from ? { remoteJid: "393470602054-1351628616@g.us" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `${YahahaHayyuk}`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync('lib/logo.jpeg')} } }, ptt: true })
				break
		        case 'clearall':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				anu = await dp.chats.all()
				dp.setMaxListeners(25)
				for (let _ of anu) {
				dp.deleteChat(_.jid)
				}
				reply(dpuhy.clears())
				break
				case 'setprefix':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return
				prefix = args[0]
				reply(`Prefix berhasil di ubah menjadi : ${prefix}`)
				break 
				case 'resetlimit':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				var obj = []
				fs.writeFileSync('./database/limit.json', JSON.stringify(obj))
				await reply(`LIMIT BERHASIL DI RESET`)
				break
		        case 'setlimit':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return
				limitawal = args[0]
				reply(`Limit berhasil di ubah menjadi : ${limitawal}`)
				break
		        case 'setmemlimit':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				if (args.length < 1) return
				if (isNaN(args[0])) return reply('Limit harus angka')
				memberlimit = args[0]
				reply(`Change Member limit To ${memberlimit} SUCCESS!`)
				break
				case 'addbadword':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (args.length < 1) return reply( `Kirim perintah ${prefix}addbadword [kata kasar]. contoh ${prefix}addbadword bego`)
                const bw = body.slice(11)
                bad.push(bw)
                fs.writeFileSync('./database/bad.json', JSON.stringify(bad))
                reply('Success Menambahkan Bad Word!')
                break
                case 'delbadword':  
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
                if (args.length < 1) return reply( `Kirim perintah ${prefix}addbadword [kata kasar]. contoh ${prefix}addbadword bego`)
                let dbw = body.slice(11)
                bad.splice(dbw)
                fs.writeFileSync('./database/bad.json', JSON.stringify(bad))
                reply('Success Menghapus BAD WORD!')
                break 
                case 'setppbot':
				if (!isGroup) return reply(dpuhy.groupo())
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				dp.updatePresence(from, Presence.composing) 
				if (!isQuotedImage) return reply(`Kirim gambar dengan caption ${prefix}setppbot atau tag gambar yang sudah dikirim`)
				enmedia = JSON.parse(JSON.stringify(dap).replace('quotedM','m')).message.extendedTextMessage.contextInfo
				media = await dp.downloadAndSaveMediaMessage(enmedia)
				await dp.updateProfilePicture(botNumber, media)
				reply('Makasih profil barunya😗')
				break 
				case 'ban':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				bnnd = `${args[0].replace('@', '')}@s.whatsapp.net`
				ban.push(bnnd)
				fs.writeFileSync('./database/banned.json', JSON.stringify(ban))
				fakestatus(`Nomor ${bnnd} telah dibanned!`)
				break
				case 'unban':
				if (!dap.key.fromMe) return reply(dpuhy.ownerb())
				dap = `${args[0].replace('@', '')}@s.whatsapp.net`
				unb = ban.dpuhyexOf(dap)
				ban.splice(unb, 1)
				fs.writeFileSync('./database/banned.json', JSON.stringify(ban))
				fakestatus(`Nomor ${ya} telah di unban!`)
				break
				default:
			if (isGroup && !isCmd && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						reply(dpuhy.cmdnf(prefix, command))
					} else {
						console.log(color('[ERROR]','red'), 'Unregistered Command from', color(sender.split('@')[0]))
					}
					}
		} catch (e) {
			            e = String(e)
			if (e.includes('this.isZero')){
return
}
			console.log('Error : %s', color(e, 'red'))
		}
	})
}
starts()